# Source materials and scope

- `UPDATED_SURVEY_WORKBOOK.xlsx` is the updated survey workbook used to produce the N=26 anonymised respondent dataset.
- `INTERVIEW_RECORDS_P01_P05.md` in the interview folder contains the supplied detailed interview records for P01–P05.
- P00 is included in the consolidated report and the P00–P05 interview findings CSV as the researcher-user perspective. It is identified transparently as such.
- The final report and derived CSVs are the canonical outputs. Earlier duplicate report drafts and alternate export copies are intentionally omitted.
- Existing PowerPoint files are not included or modified, per the instruction to leave the presentation alone.
