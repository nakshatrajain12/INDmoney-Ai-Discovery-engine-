# INDmoney First-Year SIP Research — Complete Project Pack

This archive consolidates the final research deliverables, clean datasets, supporting evidence, source materials, design reference, and the latest presentation supplied by the user.

## Start here
- `00_Presentation_and_Design_Reference/NL_INDmoney_Solution_Latest.pptx` — latest supplied presentation; included as-is and not edited.
- `00_Presentation_and_Design_Reference/NL_photos_Design_Reference.pdf` — visual/reference deck.
- `01_Final_Report/FINAL_SIP_RESEARCH_REPORT.md` — consolidated research report.
- `02_Clean_Survey_Data/` — anonymised respondent-level CSV and derived survey tables.
- `03_Interview_Findings/` — P00–P05 interview findings and P01–P05 source interview records.
- `04_Evidence_and_Validation/` — 16-hypothesis register and supporting evidence ledger.
- `05_Source_Materials/` — updated survey workbook and original source research/interview documents.

## Research basis
- Survey analysis uses N=26 as the accepted full survey sample, as instructed by the user.
- All platform responses are retained in the overall mixed-platform research; platform-specific statements are labelled where relevant.
- Interview findings include P00–P05, including the Groww comparison case P05.
- P00 is included as a participant/researcher-user account and should be interpreted with that positional context.
- The supplied latest PPTX and NL_photos reference PDF are preserved unchanged.

## File hygiene
- One canonical copy of each deliverable is included.
- Older alternate PPTX revisions and duplicate ZIP archives are not included.
- `MANIFEST.csv` lists the files and SHA-256 hashes for integrity checking.
