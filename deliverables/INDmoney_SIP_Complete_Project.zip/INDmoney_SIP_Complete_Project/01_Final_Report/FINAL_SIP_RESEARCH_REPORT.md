# First-Year SIP Experience Research
## Final consolidated research, segmentation, validation and evidence pack

**Research cut-off:** 6 November 2026  
**Survey base:** N=26 eligible SIP respondents  
**Qualitative interviews:** P00–P05 (six cases; P00 is the researcher-user perspective)  
**Scope:** first-year SIP experience, early expectations, investor confidence, payment continuity, information-seeking, affordability and product opportunities for investment apps.

> **Evidence convention.** This document treats all 26 survey responses that pass the survey's stated consent, age and personally-started-SIP criteria as the research dataset, as requested. It includes every interview case P00–P05. The survey is cross-platform: findings describe SIP investors in the sample, not INDmoney customers alone. P05 is a Groww comparison case. P00 is included transparently as the researcher-user perspective.

---

## 1. Executive summary

The evidence converges around three core problem families:

1. **Information clarity and early expectation-setting.** Investors may not know how to interpret XIRR, short-term return figures or volatility, or whether early performance is normal. The 3–6 month group is particularly notable: all 7 respondents selected quick positive returns as an expectation; 6/7 seriously considered changing their SIP; 5/7 named confusing or disappointing returns as the main reason.
2. **Payment and mandate friction.** 11/26 reported an instalment failure or mandate issue in the dedicated question. Interview P03 describes a failed UPI debit with a generic notification and manual recovery; P00 reports a failed debit and unclear advance communication; P02 describes mandate uncertainty around pausing.
3. **Affordability and continuity controls.** 15/26 said monthly affordability informed their initial SIP amount. P02 illustrates how a cash-flow shock can turn a temporary pause into a prolonged lapse when pause/reduce/cancel states and restart paths are unclear. P00 and P04 illustrate different ways users preserve continuity through small amounts, goals and salary-aligned dates.

The most consistently selected improvement is clearer return or volatility explanations (9/26). Payment-failure recovery (4/26) and upcoming-debit visibility (3/26) follow. Easier pause/edit controls and a simple goal tracker each received 3/26 selections.

**Strategic implication:** prioritise an in-app first-year SIP guidance experience that explains performance in context, sets realistic expectations, and connects payment status to a clear next action. Pair this with transparent pause/reduce/resume controls. Do not frame this as a proven retention intervention: the research validates problem signals and needs, not feature-level lift or causal churn reduction.

## 2. Research design and sample

### 2.1 Survey sample

The updated workbook contains 27 submissions. The research dataset used here is **N=26**: all respondents who agreed to participate, confirmed they were 18 or older, and indicated that they had personally started a mutual-fund SIP. The one submission that selected “Never started” is outside the SIP-starter target population. No other response is excluded from the N=26 dataset.

The survey is descriptive and cross-platform. Platform/channel distribution:

| Platform/channel | Respondents |
|---|---:|
| INDmoney | 11 |
| Groww | 8 |
| Bank or financial institution | 3 |
| Other | 2 |
| Zerodha Coin | 1 |
| Adviser or distributor | 1 |
| **Total** | **26** |

Tenure distribution:

| First SIP tenure | n |
|---|---:|
| 1–3 months | 1 |
| 3–6 months | 7 |
| 6–12 months | 7 |
| 12–24 months | 3 |
| More than 2 years | 7 |
| Don’t remember | 1 |
| **Total** | **26** |

Current SIP status:

| Status | n |
|---|---:|
| Active with regular debits | 19 |
| Active with failed or missed debits | 1 |
| Paused | 3 |
| Stopped or cancelled | 2 |
| Completed tenure | 1 |
| **Total** | **26** |

20/26 respondents said this was their first mutual-fund investment; 5 had invested before and 1 was unsure.

### 2.2 Method and interpretation

- Small, non-probability, self-reported survey; percentages describe this sample only.
- Mixed-platform survey; do not label all findings as INDmoney-specific.
- Multi-select questions overlap. Their option counts must not be summed as unique respondents.
- The dedicated payment/mandate question and the separate issue checklist are different measures and must remain separate.
- “Considered pausing/reducing/stopping” is not the same as actually pausing or stopping.
- Interview quotes and case details are qualitative evidence, not prevalence estimates.
- P00 is included but identified as the researcher-user perspective; its reported ₹300 penalty is not independently verified.
- P05 is included as a Groww comparison case and must not be attributed to INDmoney.

## 3. User segmentation

The survey and interviews suggest four actionable behavioural segments. These are research-derived working segments, not statistically clustered or mutually exclusive populations.

### Segment A — Expectation-mismatch investors
**Core signal:** particularly visible in the 3–6 month tenure cohort. All 7/7 expected quick positive returns; 6/7 seriously considered a change; 5/7 named confusing/disappointing returns as the main reason. 2/7 reported actually changing course.

**Needs:** a realistic first-year roadmap, plain-language performance interpretation, contextual explanation of volatility and a clear distinction between short-term movement and long-term outcomes.

**Evidence:** P01 (INDmoney) expected visible growth by month three and struggled with XIRR; P05 (Groww) describes creator-shaped expectations and conflicting advice. P00 also describes anxiety during red-portfolio periods but continued.

**Product implication:** onboarding and in-context learning should explain what investors can and cannot infer from early returns, without giving personalised investment advice or pushing products.

### Segment B — Payment-friction / recovery-seeking investors
**Core signal:** 11/26 reported a payment or mandate issue in the dedicated survey question; 5/26 separately selected auto-debit/mandate failure in the issue checklist.

**Needs:** advance debit visibility, precise failure reasons, clear next steps, confirmation whether the SIP remains active, and a reliable retry/recovery path.

**Evidence:** P03 had a UPI daily-limit failure, received a generic “failed” notice and manually retried; P00 reports a failed debit and unclear advance communication; P02 was unsure about mandate implications while pausing.

**Product implication:** build a payment-status and recovery flow that tells users what happened, what remains active and what action is available.

### Segment C — Cash-flow constrained / control-seeking investors
**Core signal:** 15/26 used monthly affordability to decide their initial amount. 3/26 named income/cash-flow drop as the main reason for considering a change; 3/26 selected easier pause/edit controls as their most valuable improvement.

**Needs:** flexible amount management, clear pause/reduce/cancel distinctions, transparent mandate implications and restart prompts.

**Evidence:** P02 paused a ₹5,000 SIP after freelance income fell and rent pressure increased; P00 intentionally started small and gradually increased; P04 aligned the debit date with salary and a long-term goal.

**Product implication:** make continuity controls understandable and reversible. Test step-down, skip, pause and resume flows before assuming a specific feature will improve retention.

### Segment D — Goal-anchored confident continuers
**Core signal:** 19/26 reported active regular debits; 9/26 said they had not seriously considered changing their SIP. In the flat/negative-return question, 9/26 selected continuing as usual (see the raw CSV for the full option distribution).

**Needs:** accurate goal progress, low-noise monitoring and predictable debit scheduling rather than frequent nudges.

**Evidence:** P04 maintained a long horizon, budgeted an affordable amount and aligned the debit after salary; P00 also continued despite anxiety.

**Product implication:** offer reassurance and controls without over-notifying or pressuring confident users.

## 4. Survey findings (N=26)

### 4.1 Expectations and early-tenure experience

- 12/26 selected quick positive returns among their first 6–12 month expectations.
- In the 3–6 month cohort, 7/7 selected quick positive returns.
- 17/26 seriously considered pausing, reducing or stopping: 11 considered it but continued; 6 said they considered it and did; 9 said no.
- Across the full sample, 7/26 named confusing or disappointing returns as the main reason for a change.

The 3–6 month cohort is the clearest expectation-mismatch signal, but n=7 is small. It supports a focused product hypothesis, not a market-wide prevalence claim.

### 4.2 Performance understanding and confidence

- 11/26 reported confusing performance terms.
- 11/26 were unsure whether returns were normal.
- 16/26 rated their confidence in understanding SIP metrics at 1–3 on the 1–5 scale.
- 9/26 selected clearer return or volatility explanations as the single change that would most improve their SIP journey.

This is the strongest directly measured problem area in the survey. P01’s XIRR confusion and P05’s inability to interpret the app chart give concrete examples. P04 is an important counterexample: goal clarity and a long horizon reduced the need for external reassurance.

### 4.3 Payment and mandate friction

- Dedicated payment/mandate question: 6/26 said “Yes, once”; 5/26 said “Yes, more than once”; 14/26 said “No”; 1/26 said “Not sure”.
- Separate issue checklist: 5/26 selected auto-debit or mandate failure.
- 4/26 selected clear payment-failure recovery as their most valuable improvement; 3/26 selected better upcoming-debit visibility.

Do not combine the 11/26 dedicated-question result with the 5/26 checklist result. They are distinct question formats. The data supports a real operational friction problem, but does not establish that payment failures independently cause churn.

### 4.4 External help and information seeking

25/26 selected at least one external help source. The most selected sources in the updated workbook include friends/family, Google, YouTube, Reddit/forums, financial advisers, influencers and AMC websites (exact counts are in `survey_frequency_tables.csv`).

P01 used Google, a forum and a colleague; P05 used creator videos, a forum and a friend. These examples show that outside information can both increase uncertainty and resolve it. P04 did not seek external reassurance. The evidence supports external help-seeking, not a blanket claim of dependency or a causal relationship with stopping.

### 4.5 Affordability and SIP amount

15/26 selected monthly affordability as the basis for deciding their first SIP amount. P02’s amount became difficult after an income shock; P00 deliberately started with a small amount and increased later; P04 selected an amount aligned to budget and salary timing. The evidence supports affordability-aware controls, but not a universal need for automated amount recommendations.

### 4.6 Single most valuable improvement

| Improvement | n |
|---|---:|
| Clearer return or volatility explanations | 9 |
| Clear payment-failure recovery | 4 |
| Better upcoming-debit visibility | 3 |
| Simple goal tracker | 3 |
| Easier pause or edit controls | 3 |
| Faster support | 2 |
| No help needed | 2 |
| **Total** | **26** |

## 5. Interview findings: P00–P05

### P00 — Researcher-user / INDmoney
Started with ₹500 split across three SIPs and later increased the total to ₹850. Continued despite red-portfolio anxiety. Experienced one failed debit attributed to insufficient funds, did not recall a clear advance notification and later noticed a reported ₹300 penalty. Wanted a one-day pre-debit reminder and itemised explanations of costs and taxes. This is included as a first-person researcher-user account, not represented as an independent recruited interview. The penalty is unverified.

### P01 — INDmoney, first-time investor, ~5 months
Expected visible growth by month three. When returns turned slightly negative, did not understand XIRR and searched externally, finding conflicting explanations. Considered pausing but continued, partly because the rupee loss was small and a colleague reassured them. Core need: explain whether the observed return is normal for the investor’s tenure.

### P02 — INDmoney, first-time investor, ~9 months
Paused a ₹5,000 SIP after freelance income dropped and rent pressure increased. Was unclear about the difference between pause, reduce and cancel, and worried about mandate implications. Intended to restart after one month but did not; no reminder prompted resumption. Core need: understandable controls, lower-amount option and restart support.

### P03 — INDmoney, first-time investor, ~3 months
A UPI daily limit caused a failed debit. The notification stated that the instalment failed but did not explain why or what to do. The participant checked the bank app, identified the limit issue and manually retried. Continued after the next debit succeeded. Core need: reason, next step, SIP status and one-tap recovery.

### P04 — INDmoney, first-time investor, ~10 months
A goal-driven continuer saving for a house deposit. Chose an affordable ₹4,000 amount and aligned the debit date after salary. Continued through a market dip without external reassurance. Mildly disliked cross-sell prompts but ignored them. This is a disconfirming case against assuming every investor needs frequent reassurance or intervention.

### P05 — Groww comparison case, first-time investor, ~5 months
Creator videos shaped expectations of high returns within a few months. Sideways or negative performance led to conflicting online advice. A forum explanation and a friend helped the participant stay invested and reduce checking frequency. Core need: explain what a normal first year can look like. P05 is included in the cross-platform SIP research but is not an INDmoney user.

### Cross-interview synthesis

| Theme | Cases | What the cases show |
|---|---|---|
| Early return expectations / performance clarity | P00, P01, P05; counterexample P04 | Context and plain-language interpretation can matter; not every investor responds to a dip with panic. |
| Payment communication and recovery | P00, P03; adjacent control confusion P02 | A failure message must explain cause, next step and whether the SIP remains active. |
| Cash-flow and pause/resume | P00, P02, P04 | Affordability, amount selection and debit timing influence continuity; users need control without ambiguity. |
| External information | P01, P05; counterexample P04 | Outside sources can confuse and reassure; causal effect on retention is not established. |
| Cross-sell / product noise | P01, P04 | Some annoyance is observed, but the survey does not establish this as a major SIP problem. |

## 6. Validation of all 16 hypotheses

The register contains 3 formal research hypotheses, 3 product hypotheses and 10 AI Discovery Engine themes. These are not 16 independent findings: several overlap and should be grouped into problem families.

| ID | Hypothesis / theme | Evidence-based verdict |
|---|---|---|
| H1 | 3–6 month expectation-versus-experience gap | **Validated descriptively, narrow subgroup.** 7/7 in this cohort expected quick positive returns; 6/7 considered a change; 5/7 named confusing/disappointing returns as the main reason. Small n; no causal inference. |
| H2 | Payment/mandate friction contributes to avoidable interruption | **Reframed and supported.** 11/26 reported an issue; interviews show unclear failure communication and control confusion. The survey does not establish causal retention impact. |
| H3 | External validation and conflicting advice trigger pauses | **Reframed and supported.** 25/26 used at least one external source; P01/P05 describe conflicting advice. External help also reassured and retained P05; causality is unproven. |
| P-H1 | Flexible controls (skip, step-down, pause, return-date) | **Supported at problem level.** P02 demonstrates cash-flow and pause ambiguity; 3/26 chose easier pause/edit controls. Exact feature demand and retention lift untested. |
| P-H2 | Failure recovery (reason + next step + retry) | **Supported at problem level.** Payment issue reports and P03/P00 support the friction; one-tap recovery efficacy untested. |
| P-H3 | Self-sized amount / easy adjustment | **Partially validated.** 15/26 used affordability to set amount; P02 and P00 illustrate different amount trajectories. Broad need for automated sizing not established. |
| T1 | Red Portfolio Panic | **Partially validated / reframed.** Anxiety appears in P00/P01/P05, but P04 continued confidently and the survey shows many continue through flat/negative returns. Do not assume red portfolios routinely cause exits. |
| T2 | Expectation vs Reality Gap | **Validated in a narrow descriptive form.** Overlaps H1; treat as one early-expectation problem family, not a separate discovery. |
| T3 | Information Desert | **Strongest support / validated.** 11/26 reported confusing terms, 11/26 unsure if returns were normal, 16/26 had confidence 1–3; 9/26 chose clearer explanations. P01 and P05 give examples; P04 is counterevidence. |
| T4 | Mandate & Payment Friction | **Supported / validated at problem level.** 11/26 on dedicated payment item and P03/P00 examples. Keep separate from 5/26 issue-checklist selection. |
| T5 | External Validation Seeking | **Supported after narrowing.** 25/26 selected at least one external source; this is common information-seeking, not proof of dependency. |
| T6 | Over-Monitoring Anxiety | **Partially validated.** Checking frequency is measured and P01/P05 describe frequent checking, but a causal link between checking and anxiety or churn is not established. |
| T7 | Peer Influence Dependency | **Reframed and supported.** Friends/colleagues appear as sources of advice and reassurance; dependency is too strong a label. |
| T8 | Cross-Selling Fatigue | **Insufficient evidence.** Some interview comments show mild annoyance; no strong survey measure or link to SIP behaviour. |
| T9 | Support Resolution Gap | **Insufficient evidence.** Few direct mentions; unclear product flows should not be conflated with support-team resolution quality. |
| T10 | Hidden Charges & Tax Complexity | **Insufficient evidence / isolated signal.** P00 reports a ₹300 penalty and asks for tax/cost clarity; no dedicated survey measure or repeated independent signal. |

### 6.1 Evidence-support ranking

1. **T3 — Information clarity** (very strong direct survey support and interview examples).
2. **T4 — Payment/mandate friction** (strong problem-level evidence; causality not established).
3. **H1/T2 — Early expectation mismatch** (strong within the small 3–6 month cohort).
4. **H3/T5/T7 — External information and social reassurance** (common behaviour; effect is mixed).
5. **P-H2 — Failure recovery** (supported need, feature efficacy untested).
6. **P-H1/P-H3 — Flexible controls and amount adjustment** (credible use cases, feature demand not broad).
7. **T1/T6 — Red-return anxiety and over-monitoring** (partial; counterexamples matter).
8. **T8/T9/T10 — Cross-sell, support resolution, charges/tax** (insufficient primary evidence).

### 6.2 Avoid double-counting

- H1 and T2 overlap on early expectation mismatch.
- H2, P-H2 and T4 cover research hypothesis, product response and engine theme around payment friction.
- H3, T5 and T7 overlap around external sources and social influence.
- T1 and T6 overlap around negative-return anxiety and checking.
- P-H1 and P-H3 overlap around affordability and contribution adjustment.

## 7. AI Discovery Engine: supporting evidence, not validation authority

The repository review reports 8,179 ingested signals and 3,079 cleaned evidence points from five sources. The engine generated ten themes and opportunity scores. The score implemented in `pipeline/stage3_cluster.py` is:

`0.30 × frequency + 0.30 × severity + 0.25 × actionability + 0.15 × recency`

The displayed ranking is an opportunity-prioritisation output, not customer prevalence, churn probability or hypothesis validation. The corpus includes app-store reviews, Reddit, ValuePickr, TradingQ&A, YouTube and other sources; it is not restricted to INDmoney users or first-year SIP investors.

Repository review limitations:
- The 20-item golden-set comparison is not an independent held-out production evaluation.
- Representative quotes are selected substantially by quote length rather than robust semantic relevance.
- Some quotes assigned to themes are weakly related, concern other platforms or general investing.
- Theme counts and corpus shares describe the collected corpus, not the proportion of customers experiencing a problem.
- Documentation and implementation have a scoring inconsistency; the displayed ranking matches the Stage 3 weighted-sum formula.

Use the engine to discover and prioritise themes for human investigation. Use the N=26 survey and P00–P05 interviews to assess whether a problem is present in this research sample.

## 8. Product implications and recommended action

### Priority 1 — First-year performance clarity
- Explain invested amount, current value, absolute return and XIRR in plain language.
- Give tenure-aware context for early SIP performance and volatility.
- Provide neutral explanations and avoid implying that short-term performance predicts long-term outcomes.
- Validate comprehension and trust, not merely clicks or time spent.

### Priority 2 — Payment visibility and recovery
- Show the next debit date and expected amount.
- Explain failed-debit reason, whether the SIP/mandate remains active, and the next available action.
- Provide a safe retry path and clear status after retry.
- Test whether a pre-debit reminder reduces missed instalments without increasing notification fatigue.

### Priority 3 — Flexible continuity controls
- Make pause, reduce, cancel and resume meanings explicit.
- Explore step-down or skip options as hypotheses, not assumed solutions.
- Provide restart reminders only when users opt in or signal intent.
- Make debit-date alignment and amount affordability easier to manage.

### Priority 4 — Goal-led, low-noise experience
- Support accurate goal progress and long-horizon framing.
- Avoid unnecessary cross-sell or repeated reassurance prompts.
- Allow confident users to keep the experience quiet.

## 9. What remains unproven / next validation steps

1. Whether clearer performance explanations measurably improve comprehension, confidence or SIP continuity.
2. Whether payment failure communication and one-tap recovery reduce repeat failures or missed instalments.
3. Whether pause/reduce/skip/resume controls prevent permanent lapse after temporary cash-flow shocks.
4. Whether reminders help without causing notification fatigue.
5. Whether the 3–6 month pattern replicates in a larger and more balanced cohort.
6. How INDmoney users differ from Groww, bank, Zerodha and other-channel users; the present sample is mixed-platform and small.
7. Whether support quality, cross-sell fatigue, charges and tax explanation are meaningful problems beyond isolated accounts.

## 10. Reproducibility and companion files

This pack contains:

| File | Purpose |
|---|---|
| `survey_clean_anonymized.csv` | All N=26 survey rows, with names/contact details and timestamps removed; stable respondent IDs added. |
| `survey_multiselect_long.csv` | One row per respondent-option for multi-select questions. |
| `survey_frequency_tables.csv` | Frequency counts for categorical and multi-select responses. |
| `cohort_3_to_6_months.csv` | Focused cohort evidence for the early-tenure expectation mismatch. |
| `interview_findings_P00_P05.csv` | Structured findings for every interview P00–P05. |
| `supporting_evidence_ledger.csv` | Evidence statements, source/base, interview links and interpretation limits. |
| `hypothesis_validation_register_16.csv` | Machine-readable register of all 16 tested hypotheses, based on the source report’s hypothesis matrix. |

**Privacy note:** the raw workbook includes respondent names/contact information. The clean CSV intentionally removes these fields. Do not distribute the raw workbook with the research pack.

---

## Appendix A — Key definitions

- **SIP:** Systematic Investment Plan.
- **XIRR:** a money-weighted annualised return measure that accounts for the timing of cash flows.
- **Considered a change:** selected “Yes, but continued” or “Yes, and did”; this does not necessarily mean the SIP was stopped.
- **Multi-select:** a respondent could select more than one option; option counts overlap.
- **Validated:** evidence supports the claim as narrowly framed in this sample; it does not imply population-level or causal proof.
- **Not validated / insufficient:** the available study evidence is too thin; it does not prove the problem is absent.
