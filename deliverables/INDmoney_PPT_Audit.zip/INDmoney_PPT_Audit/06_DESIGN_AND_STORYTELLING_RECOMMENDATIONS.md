# 06 — Design, Storytelling and Proposed Final Sequence

**Limit:** I could not render slides. This audit uses (a) shape/font metrics from the PPTX, (b) the extracted text of `NL_photos_Design_Reference.pdf` (10 pages, 1440×818 pt), and (c) the structure of the reference. I did not view page images, so colour, imagery and whitespace judgements are limited to what the files let me measure.

## A. What the reference deck does (and the facts I could extract)

| Reference page | Role | Structural pattern |
|---|---|---|
| 1 | Overview | Big stat tiles, launch/features, competitors, 17 image assets; nav tabs |
| 2 | AI Engine | Four numbered pipeline stages, data counts, findings and a chart |
| 3 | Segmentation | Three cards: Segment 1 (selected) / 2 / 3 (not selected) |
| 4 | User Research | Hub page: survey (N=33), links, interview notes (N=5) |
| 5 | Validation | Hypothesis cards each ending in a verdict tag (CONFIRMED / RE-FRAMED); "What we didn't see coming"; legend S = survey, I = interviews, E = engine |
| 6 | Problem | 5 questions (True problem / Who / How do we know it's real / Value / Why now) with **S/I/E-tagged evidence** |
| 7 | Solution | S1/S2/S3 cards + RICE table |
| 8 | Prototype | Six-step annotated user flow with screens |
| 9 | Metrics & usability | North Star definition, metric table with "What it means / Why it matters", **usability test (N=2) observations → fixes** |
| 10 | GTM & risks | Risk/mitigation, 3-phase rollout with weeks |

The deck you built follows this skeleton faithfully through slide 7. That is the right call and should be preserved.

## B. Current deck against the reference

| Dimension | Current deck | Reference | Gap and action |
|---|---|---|---|
| Visual consistency | Uniform nav, pills, card style across 1–7 | Same | Good. Keep. |
| Typography | Arial 17–19 pt body, Canva Sans for nav/titles; min 14 pt (nav). Slide is 20 in wide, so ≈ 11–12.5 pt at 13.33 in | Similar scale | Readable, but dense: slide 3 has 2,929 characters, slide 6 2,608, slide 7 2,455, slide 4 2,243. Target ≤1,400 on content slides; move caveats to a 1-line footnote strip. |
| Evidence tagging | Source in speaker notes only | **S/I/E tags on the slide** | Add S/I/E/P(rototype) chips beside each claim (survey, interview, engine, public stat). P0 for slides 4–6. |
| Verdict tags | Slide 5 has VALIDATED / PARTIAL / NOT VALIDATED | CONFIRMED / RE-FRAMED chips | Keep; add colour-coded chips. |
| Charts | 6 native charts (1, 2×2, 4×3) | Reference leans on tiles and cards | Charts are fine; fix those that mislead (slide 2 window chart: delete). |
| Imagery / icons | No picture shapes detected by python-pptx on any slide (the pack contains PNG/SVG media, so some graphics may be fills); no screenshots | 17 image assets on p1; prototype screens on p8 | Add product screenshots (INDmoney SIP screen with failed-debit notice; engine UI), prototype screens, simple icons per stage. |
| Whitespace | Dense columns, little breathing room on 3, 6, 7 | Moderate | Cut text; use one visual per slide. |
| Section navigation | Tabs present on all slides, "Sources" in nav but missing | Tabs present | Add Sources; highlight the active tab (check the active-tab state on each slide). |
| Footnotes | Absent on slides; all in notes | Legend on slide | Add a 10–11 pt footnote line with denominator and source on every data slide. |
| Slides 8–10 | Empty | Full | Fill (below). |

**Scrub:** speaker notes on slides 1–7 hold working text ("CHECK BEFORE SUBMITTING", "PROVENANCE FLAGS (confirm before submission)", "Rebuilt 6 Nov 2026… Replaces an earlier version built on a mock survey"). Move to a private file before sharing the PPTX; the mock-survey sentence is damaging if seen.

**Preserve:** the visual identity (pills, cards, tab nav), the "What cuts against the story" box, the evidence chain on slide 6.

## C. Per-slide design changes

| Slide | Change |
|---|---|
| 1 | Make the five tiles consistent: each shows a number, a one-line meaning, and a source chip. Replace tile 5. Put the 3 competitors as a small table rather than three text blocks. Replace the P₁…P₅ formula with a 4-step stage strip. |
| 2 | Replace the window chart with a "tenure known vs unknown" bar. Source chart → stacked by product. Add a "what the engine can and cannot tell us" two-column box. |
| 3 | Waffle chart of the 14 first-year first-timers (coloured by confused / changed). Three archetype cards shrink to name, rule, n, one need, one quote. Add an INDmoney-only mini-column. |
| 4 | Keep the layout; update every figure and add the N=26 provenance line. Add P00 as a small "context" card. |
| 5 | Add colour to verdict chips; show the engine score and the survey figure side-by-side as a bar pair for each theme. |
| 6 | Keep. Add S/I/E tags to each bullet. |
| 7 | Replace three text cards with a 3-column comparison matrix (reach, evidence, effort, risk, decision). Shift the RICE note to the next slide. |
| 8 | Six-step flow with real screenshots (as the reference does), annotated; deployed URL and QR. |
| 9 | Safety and eval gate: architecture diagram (input → rules table + vetted sources → LLM explanation → advice filter → confidence label → fallback). |
| 10 | NSM box, KPI tree diagram, E1–E3 experiment cards. |
| 11 | Usability: task, participants (real N), success criteria, observed result, fix. Mark "pending" rows clearly. |
| 12 | Three-phase rollout (weeks), risk/mitigation table. |
| 13 | Sources with access dates. |

## D. Proposed final slide sequence

| # | Section | Title (suggested) | One-sentence takeaway | Key content | Evidence required | Visual | Status |
|---|---|---|---|---|---|---|---|
| 1 | Overview | Starting a SIP Is Easy to Copy; Keeping It Going Is INDmoney's Opening | Industry SIPs are record-high, copying onboarding is easy, retention is the differentiator | Tiles (verified stats), competitor table, goal, rules | Verified stats (file 03) | Tiles + table | **Revise** |
| 2 | AI Engine | 8,179 Posts → 3,079 Signals: People Don't Understand Their Returns and Their Debits Fail | Public reviews point to clarity and payments, but cannot show timing or prevalence | Pipeline, source/product mix, top themes, what the engine can/can't say | Fixes from file 04 §E | Stacked bar + table | **Revise** |
| 3 | Segmentation | 13 of 26 Are Unsure or Confused About Returns; 5 of the 6 Who Changed Course Were | Early-doubt first-timers are the best-evidenced pilot segment | Archetypes with n, INDmoney-only view | N=26 + N=21 | Waffle grid | **Revise** |
| 4 | User Research | Confusion, Not Panic | Doubt is mostly about meaning and mechanics, not market panic | Survey tiles, charts, interviews P00–P05, counter-evidence | N=26 recomputed | Tiles + charts | **Revise** |
| 5 | Validation | Clarity and Payment Gaps Hold Up; Panic and Cross-Sell Are Unproven | Engine themes tested against the survey | Table, tiers, surprises | N=26, all 16 | Table + chips | **Revise** |
| 6 | Problem | Newcomers Can See Their SIP but Not What It Means or What to Do | Two moments: first flat/red figure; first failed debit | Evidence chain, problem, who, value, why now | S/I/E tags | Chain diagram | **Light revise** |
| 7 | Solution | Return Mode First; Debit Explainer in Parallel | Narrow first, bundle later | 3 options, RICE (N=26), decision, what's cut | file 05 §B | Matrix | **Revise** |
| 8 | Prototype | How the Assistant Works on a Real Task | A user enters a figure or a failure and gets meaning, status and next step | 6-step flow, deployed URL | Real screens | Screens | **New** |
| 9 | AI quality & safety | Built to Say "Not Sure" | Answers are rules-first, cited, advice-free and eval-gated | Architecture, refusal, fallback, eval gate, golden set | 40-scenario set + results | Diagram | **New** |
| 10 | Metrics | One Number, Five Levers | NSM and KPI tree with guardrails and experiments | Definition, corrected formula, tree, E1–E4 | file 05 §C–D | Tree | **New** |
| 11 | Usability testing | What 3+ Real Users Did (or: Test Plan) | What changed after users tried it | Task, participants, observed, fixes | **Only real sessions** | Table | **New** |
| 12 | GTM & Risks | Pilot, Measure, Expand | Staged rollout with risk gates | Phases, risks, mitigations, owners | — | Timeline + table | **New** |
| 13 | Sources | Sources and Access Dates | All claims traceable | URLs + dates | file 03 | List | **New** |
| A1 | Appendix | Evidence Integrity and Sensitivity | N=26 composition and effect of exclusions | Table from file 04 §A | — | Table | **New** |
| A2 | Appendix | Journey Map | Where doubts arise month by month | Months 0–12 with moments, emotions, outcomes | P01–P05, P00 | Journey map | Optional |

Removals: slide-2 window chart; "paused SIPs" wording; "bank charges" value claim; the P₁…P₅ breakdown. Merge: shared numbers of slides 4–5; hypotheses cards of slide 3 into slide 5/10. Reorder: none required.
