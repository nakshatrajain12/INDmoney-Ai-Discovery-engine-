# 07 — Final Action Plan

No changes have been made to the PPTX or any research file. You choose what to implement.

## C. Slide-by-slide correction list (exact edits)

**Slide 1**
- Title → "Starting a SIP Is Easy to Copy. Keeping It Going Is INDmoney's Opening."
- Tile 3: "78.5%" → "49.7 lakh stopped or ended per 63.3 lakh new SIPs (Sep 2026)"; add "includes completed SIPs".
- Tile 5: delete the 54.2% tile. Use "36% of 3,079 clean signals concern INDmoney", or "7 of 7 in the 3–6-month survey cohort expected quick returns (n=7)".
- Chart: use one source for 34.4/19.9 (Outlook) or 34.09/19.64 (Cafemutual); footnote the growth and ticket-size confound.
- Competitors: label "NSE active broking clients"; reconcile or drop the INDmoney 7.19 L vs 10M+.
- Metric breakdown: replace the formula and percentages with the corrected stage strip (file 05 §C).
- Features: quote "SIPs via INDpay UPI", "SIP Centre"; drop "edit, pause or cancel anytime" unless you cite it.

**Slide 2**
- Title: drop "SIPs Break in Months 3–6".
- Stage 4 → "assigned to 10 pre-defined themes"; Stage 5 → remove the 95.4% claim until a real test exists.
- Source chart: add product split (INDmoney 36.2%, Zerodha Coin 25.6%, Groww 15.4%, general ≈23%).
- Delete the "When SIPs break" chart. Add "tenure known for 68 of 3,079".
- Theme table: add "corpus share ≠ prevalence"; reword T1 "What breaks".

**Slide 3**
- Title → N=26 version (file 02). Recompute Segment 1 (n=9: INDmoney 4, Groww 5; 2 changed; 8/9 confidence 1–3; 3/9 payment issue; 4/9 daily+; 7/9 in 3–6 months; 7/9 quick-return expectation).
- Segment 2: 15/26 sized by affordability; 4 gave cash-flow reasons; **1 changed (R23)**. Segment 3: 9/26 never considered; 10/26 confidence 4–5.
- Delete "Sizing (illustrative)" or restate: 11 of 14 first-year first-timers active.
- Add the sample strip: "N=26 · 20 first-timers · INDmoney 11".

**Slide 4**
- Tiles: 11/26; 11/26 (4 of 11 rated clarity 1–2); 7/7 (n=7); 17/26 considered, 6/26 changed.
- Chart 1: 12 / 4 / 2 / 2 / 2 / 1 / 1 / 1 / 1. Chart 2: 14 / 6 / 5 / 1. Chart 3: 11 / 10 / 8 / 7 / 7 / 6 / 4 / 3 / 2.
- Add P00 card. Add "condensed interview notes". Add provenance line.

**Slide 5**
- All cells to N=26 (see file 02). Tier 3 → move P-H1 to Tier 2. Replace "none of the 5 who weren't" with the payment-gap and cash-flow surprises.

**Slide 6**
- Update chain box 4 and "Who" numbers; remove "bank charges" value; rewrite "20 of 20" → 25/26.

**Slide 7**
- Update reach and RICE (60 / 25 / 60); state S3 = S1 ∪ S2; decision line; re-label "reversible controls" as "restart prompt (non-AI), in parallel"; mark Hinglish as a hypothesis; add "40-scenario set status".

**Slides 8–10 and 11 (Sources):** build per file 06 §D.

## E. Critical factual corrections (summary; full list in file 03)

| # | Claim (location) | Status | Correction |
|---|---|---|---|
| 1 | "54.2% … months 3–6" (S1 tile, S2 title/chart, S1 formula) | UNSUPPORTED | Hard-coded; 6 of 3,079 tagged 3–6 months |
| 2 | 18.4 / 21.6 / 5.8% windows | UNSUPPORTED | Same |
| 3 | `P1×P2×P3×P4+P5` | INCORRECT | Use `S+(1−S)r` |
| 4 | "6.3%" as P₂ window | INCORRECT | It is T4's corpus share |
| 5 | "20-item golden set tests the engine"; 95.4% | INCORRECT (as implemented) | Hard-coded labels; items not in corpus |
| 6 | "Signals form 10 themes" | Misleading | Themes pre-defined |
| 7 | T1 "lead to paused SIPs" | UNSUPPORTED | 0.6% record pause/cancel |
| 8 | "Failing Retention", "Mastered Onboarding" | UNSUPPORTED | No INDmoney retention data |
| 9 | All N=20 survey figures on slides 3–7 | OUTDATED | N=26 replacements in file 03 |
| 10 | "4 of 10 vs 0 of 5" | OUTDATED / unsupported | 4/12 vs 1/8; first-year 2/9 vs 1/5 |
| 11 | Segment 2 "no survey respondent changed course" | INCORRECT at N=26 | R23 |
| 12 | "7 of 9 first-year first-timers active; both off-track are Uncertain Newcomers" | OUTDATED | 11 of 14; one of three off-track isn't confused |
| 13 | Rank "n of 16" | OUTDATED | N=20 ranking; use tiers |
| 14 | "payment issues did not separate who considered a change (6/9 vs 6/11)" | OUTDATED | 8/11 vs 8/14; changed 4/11 vs 1/14 |
| 15 | FINAL report: "9/26 continue as usual" | INCORRECT | 12/26 |
| 16 | FINAL report/README/Evidence Log: Reddit in corpus | INCORRECT | 0 Reddit rows |
| 17 | `data/export` "N=35 mock survey" | Conflicting/INCORRECT | Remove or regenerate |
| 18 | "Bank charges" as a value claim | UNSUPPORTED | P00-only, unverified |
| 19 | Chart mixes Outlook and Cafemutual figures | Qualification | 0.3 pp differences; one source |
| 20 | "UPI Autopay… edit, pause or cancel anytime" | Qualification | Site: INDpay UPI, SIP Centre |

## F. Research gaps (cannot be established from current evidence)
1. INDmoney's actual first-year SIP retention, by cohort and by window (needs internal data).
2. Whether confusion *causes* stopping; the survey is cross-sectional with tiny cells.
3. Whether payment failures cause lapse; the gap 4/11 vs 1/14 is descriptive (p≈0.13).
4. When drop-off happens: the engine has tenure for 2.2% of signals; the survey's 3–6-month cohort is n=7.
5. INDmoney-only prevalence: n=11; mixed-platform evidence everywhere else.
6. Independence and provenance of R22–R26 and P01–P05; the consent-changed row; the platform-field edits on three rows.
7. Interviews inside the chosen segment: only P01 (INDmoney) and P05 (Groww).
8. Whether a plain-language explanation changes behaviour or only comprehension.
9. Whether "typical at this stage" ranges can be stated without being read as advice (legal review).
10. Real extraction accuracy of the engine, on real, blind-labelled data.
11. Usability results with ≥3 target users (brief Part 6).
12. Hinglish/free-text benefit; bank-charge incidence; support quality (T9) and charges (T10).

## G. Design improvement plan
See file 06 §B–C: S/I/E chips, footnote strip, one visual per slide, product screenshots, fill slides 8–10, add Sources, scrub speaker notes, keep the tab navigation and the pill-and-card identity.

## H. Final submission checklist

**Factual**
- [ ] Every survey number shows an N=26 denominator (and N=21 in the appendix)
- [ ] 54.2 / 18.4 / 21.6 / 5.8% removed or computed
- [ ] Golden-set claim removed or backed by a real run
- [ ] FINAL report "9/26" corrected to 12/26; Reddit references removed
- [ ] External stats single-sourced with access dates

**Research integrity**
- [ ] N=26 composition (R22–R26 mirror P01–P05) disclosed
- [ ] Consent-changed row and platform-field edits documented
- [ ] P00 labelled researcher-user; P05 labelled Groww; no INDmoney attribution of P05
- [ ] Interviews labelled "condensed"; real vs adapted stated
- [ ] `data/export` fixed or withdrawn

**Strategic**
- [ ] Title no longer asserts INDmoney retention failure
- [ ] Segment definition shows INDmoney-only n
- [ ] NSM formula corrected; denominator and "active" defined
- [ ] RICE recomputed with the tie stated; solution scope decision explicit
- [ ] Cash-flow/restart handled (even if non-AI)

**Deliverable completeness**
- [ ] Slides 8–10 built; Sources slide added
- [ ] MVP deployed URL on slide; usability results are real or marked pending
- [ ] Eval gate targets shown as targets; results only if measured

**Visual and technical**
- [ ] ≤1,400 characters on content slides; S/I/E chips; footnote strip
- [ ] Screenshots on slides 1, 8
- [ ] Speaker notes scrubbed; PDF export checked (notes don't export)
- [ ] File opens without font substitutions (Canva Sans); embed or swap
- [ ] Final proof-read and numeric cross-check against file 03
