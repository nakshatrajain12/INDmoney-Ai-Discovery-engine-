# 04 — Research, Interview, Hypothesis, Engine and Segmentation Audit

All survey figures were recomputed from `02_Clean_Survey_Data/survey_clean_anonymized.csv` (26 rows, R01–R26). Counts match `survey_frequency_tables.csv` and the updated workbook-based report, except where I flag an error. "Confused" = selected *Unsure if returns were normal* OR *Confusing performance terms* in `experienced_issues` (the deck's own definition). Fisher exact tests are descriptive only.

## A. The N=26 sample and a disclosure you need to make

**Composition.** INDmoney 11, Groww 8, bank 3, other 2, Zerodha Coin 1, adviser 1. First-time investors: 20 of 26. Tenure: 3–6 months 7, 6–12 months 7, >2 years 7, 12–24 months 3, 1–3 months 1, don't remember 1. Status: 19 active, 1 active with failed debits, 3 paused, 2 stopped, 1 completed.

**Provenance (not disclosed in the final report or the deck).** `SOURCE_RESEARCH_REPORT.md` §1.1 and §4.2–4.3 say: (a) five records appended on 6 Nov at ~00:21–00:33 closely mirror P01–P05, and (b) one record's consent changed from "No" to "Yes". The `FINAL_SIP_RESEARCH_REPORT.md` drops both caveats ("No other response is excluded").

I compared the text. `experience_narrative` in R22–R26 is a near-verbatim retelling of the P01–P05 interview records:

| Survey row | Mirrors | Evidence |
|---|---|---|
| R22 (INDmoney, 3–6 mo) | P01 | "small minus (around minus two percent)… ₹12,500 total… colleague… ignore it because it's early" |
| R23 (INDmoney, 6–12 mo, paused) | P02 | "freelance income dropped… ₹5,000 for rent… pause differed from cancel… no reminder" |
| R24 (INDmoney, 1–3 mo) | P03 | "daily UPI limit… 'instalment failed'… checked my bank app… retried manually" |
| R25 (INDmoney, 6–12 mo) | P04 | "6-year house deposit goal… ₹4,000 right after payday" |
| R26 (Groww, 3–6 mo) | P05 | "creator videos… two small/mid-cap SIPs… forum… friend" |

**Consequences.**
- The same five stories are counted twice (interview and survey).
- R22 and R26 are two of the seven people in the "3–6 month cohort".
- R23 is the *only* first-year first-timer who changed course without being confused.
- Five of the 11 INDmoney respondents are these rows, so the INDmoney-only view is the most affected.

**You told me to use N=26 and I have.** My recommendation is not to switch, but to **disclose and show the sensitivity**: *"N=26 = 21 independent survey responses + 5 entries mirroring interview cases. Headline findings hold directionally at N=21."* If any of P01–P05 are simulated or adapted, say so on the research slide. Evaluators routinely probe this, and it is far cheaper to disclose than to be found out.

### Sensitivity table (computed)
| Measure | N=26 | N=21 (R01–R21) | INDmoney only (n=11) | Deck (N=20 core) |
|---|---|---|---|---|
| Unsure returns normal / confusing terms | 11 / 11 | 9 / 9 | 5 / 4 | 8 / 8 |
| Either (confused) | 13 | 11 | 5 | 10 |
| Confidence rated 1–3 | 16 | 12 | 8 | 11 |
| Payment/mandate issue (dedicated Q) | 11 | 10 | 5 | 9 |
| Considered change / actually changed | 17 / 6 | 13 / 5 | 8 / 3 | 12 / 4 |
| Expected quick positive returns | 12 | 10 | 6 | 9 |
| Want clearer return explanations | 9 | 7 | 4 | 7 |
| 3–6-month cohort n (quick returns, considered, changed) | 7 (7, 6, 2) | 5 (5, 4, 2) | 3 (3, 3, 1) | 5 (5, 4, 2) |
| Continue as usual when flat/red | **12** | 9 | 5 | 9 |

## B. Key findings that change the story

1. **The headline contrast collapses.**

   | Group | Confused: changed / n | Not confused: changed / n |
   |---|---|---|
   | All first-time investors (n=20) | 4 / 12 | 1 / 8 (Fisher p=0.60) |
   | **First-time investors in first 12 months (n=14)** | **2 / 9** | **1 / 5** |
   | Everyone, any tenure (n=26) | 5 / 13 | 1 / 13 (p=0.16) |

   The deck's claim, "All 4 first-timers who changed course were confused… 0 of the 5 who weren't", is true only for the N=20 core and mixes tenures. Of the 5 first-timers who changed at N=26, two (R04, R05) have more than 2 years of tenure, so they are not first-year cases at all.

2. **The 3–6-month cohort is the sharpest signal, and it is real but small.** All 7 are confused, all 7 expected quick positive returns, 6 of 7 considered a change, 2 of 7 changed, and all 7 rate confidence 1–3. The comparison is stark against 6–12 months (n=7): confused 2, quick-return expectation 0, changed 1. It is still n=7, with 4 Groww and 3 INDmoney, two of them interview-mirror rows. Frame it as a hypothesis to test, not a "cliff".

3. **Payment friction looks stronger at N=26 than the deck says.** Considered a change: 8 of 11 with an issue vs 8 of 14 without (p=0.68). **Actually changed: 4 of 11 vs 1 of 14 (p≈0.13).** The old "6 of 9 vs 6 of 11" caveat should be replaced. Still not causal, but no longer "no separation". Among INDmoney only: 2 of 5 vs 0 of 5.

4. **Cash-flow is a bigger part of "actually changed" than the deck allows.** Main reasons among the 6 who changed: confusing returns 3 (R04, R11, R18), unclear time horizon 1, lost app confidence 1, income/cash-flow 1 (R23, the P02 mirror). The deck's Segment 2 claim, "no survey respondent here changed course", is **wrong at N=26**. The *only interviewed participant who actually stopped* (P02) stopped for cash flow, not for returns or debits, yet the solution drops "reversible controls".

5. **FINAL report error.** `FINAL_SIP_RESEARCH_REPORT.md` §3 Segment D says "9/26 selected continuing as usual". The CSV has **12/26** (the hypothesis register T1 row correctly says 12). 9 is the N=20 figure. Correct before anyone cites it.

6. **Platform mix.** "Uncertain Newcomers" (first-time, ≤12 months, confused, n=9) = Groww 5 + INDmoney 4. The 2 who changed are R18 (INDmoney) and R19 (Groww). Any claim of "INDmoney's target segment" needs the INDmoney-only view: n=4, 1 changed.

7. **Considered ≠ changed.** 17 of 26 considered a change and 6 did (35% of considerers). A good "surprise" insight, so keep it.

8. **Platform-field correction.** Slide-3 notes say three rows' platform changed from Groww/Groww/Zerodha to INDmoney between sheet versions. Nobody has documented who changed it or why. At N=26 this affects the INDmoney counts. Resolve before submission.

## C. Interview audit (P00–P05)

| ID | Platform | In chosen segment? | Role | Use in deck |
|---|---|---|---|---|
| P00 | INDmoney, researcher-user, ~3 yrs | No | Context, failed-debit and ₹300-penalty report | Include, labelled "researcher-user, positional; ₹300 unverified". **Currently absent from slides 3–7 except in notes.** |
| P01 | INDmoney, ~5 mo | **Yes** | Core case | Core quote; note alternative explanation (small rupee loss) |
| P02 | INDmoney, ~9 mo, paused | No (cash-flow) | Adjacent case | Evidence for reversible controls |
| P03 | INDmoney, ~3 mo | Partly (payment) | Payment case | Debit mode evidence |
| P04 | INDmoney, ~10 mo | No | **Disconfirming** | Keep |
| P05 | Groww, ~5 mo | Yes, comparison only | Comparative | Keep, labelled Groww |

**Problems**
- Brief Part 3: "Conduct 5 to 6 user interviews with respondents belonging to the segment you have chosen." Only P01 (INDmoney) and P05 (Groww) are in "Uncertain Newcomers". This is a methodological gap a mentor will spot.
- The interview records carry designed fields ("Perspective / sampling reason", "Hypothesis tested", "Competing explanation", "Grounding… Basis: P00, pack §16.2"). That is a hypothesis-driven sampling frame, which is legitimate, but several "Grounding" rows cite *P00* or *the engine corpus* as the basis for what a participant said. A reader will ask whether these are verbatim transcripts. The records are labelled "condensed". State that on the slide.
- Quotes on slide 4 do match the records verbatim (P01, P02, P03, P04, P05 checked). The P03 "I'd also like a reminder the day before" quote is correct. The P01 quote on slide 4 is exactly "I didn't know if minus two percent at five months was normal."
- **Recommended:** run 3–4 additional interviews with INDmoney first-year investors who have seen a flat or red number; use a screener (first MF, ≤12 months, INDmoney). Until then label the segment evidence as *survey-led with 1+1 interview support*.

## D. All 16 hypotheses at N=26

The register in `hypothesis_validation_register_16.csv` is consistent with the survey except where noted. Verdicts are as written there. Audit notes:

| ID | Register verdict | Audit note |
|---|---|---|
| H1 | Validated, narrow | n=7 incl. 2 interview-mirror rows. Frame as hypothesis. |
| H2 | Reframed and supported | See B3: actual-change gap 4/11 vs 1/14. |
| H3 | Reframed and supported | 25 of 26 includes R20, who ticked "Don't seek information" *and* other sources. |
| P-H1 | Supported, problem-level | **Deck tier 3 ("partial") is stale**; register upgrades it. 1 of 6 changers (R23=P02). |
| P-H2 | Supported, problem-level | 4 of 11 affected rate clarity 1–2 (mean 2.9). Deck's "3 of 9, mean 3.1" is N=20. |
| P-H3 | Partially validated | OK |
| T1 | Partial | Engine: only 0.6% of T1 signals record paused/cancelled. |
| T2 | Validated narrow | Overlaps H1. |
| T3 | Strongest | 818 of 829 T3 signals have unknown tenure; 84% "continued". |
| T4 | Validated, problem-level | Keep dedicated Q (11/26) separate from checklist (5/26). |
| T5–T7 | Reframed | OK |
| T8–T10 | Insufficient | OK |

**Rank numbers.** Slides 3, 5 and 7 quote "Rank 1 of 16 … rank 14 of 16" etc. These come from `SOURCE_RESEARCH_REPORT.md` §3.2 (N=20 basis). The N=26 final report ranks eight *groups*, not sixteen items. Either re-rank at N=26 or show tiers only.

## E. Phase 3 — AI Discovery Engine verification

Repository `nakshatrajain12/INDmoney-Ai-Discovery-engine-`: remote HEAD `ba523c1` equals the local checkout. The live site at https://in-dmoney-ai-discovery-engine.vercel.app/ (accessed 2026-11-08) shows the same numbers as the code.

| Claim | Verdict | Detail |
|---|---|---|
| 8,179 ingested | ✅ | `raw_data.jsonl` = 8,179 rows. Per-source files sum differently (YouTube 629 vs 624, TradingQ&A 315 vs 313), consistent with de-duplication. |
| 3,079 clean signals | ✅ | `filtered_data.jsonl` and `extracted_insights.jsonl` = 3,079. |
| Sources 6,054 / 922 / 624 / 313 / 266 | ✅ | Matches `source` counts. |
| "Reddit" | ❌ | `reddit_posts.jsonl` has 0 rows; no raw row has a Reddit source. The final report §7, README and Evidence Log mention Reddit; the problem statement names it. |
| Platform scope | ⚠️ | Raw: INDmoney 3,937 (48.1%), Groww 1,933, Zerodha Coin 1,239, general 1,070. **Clean signals: INDmoney 1,114 (36.2%)**, Zerodha Coin 789, Groww 473, general ≈703. The deck says nothing of this. |
| 10 themes "formed from signals" | ⚠️ | Themes are hard-coded in `THEME_DEFINITIONS` (`stage3_cluster.py`, "from implementation_plan.md §3.4"), with items assigned by an affinity score (keyword substring, emotion, product-area and DQ matches). It is classification into pre-set buckets, not discovery by clustering. |
| Keyword matching | ⚠️ | T1 keywords include "red", "down", "fall", "drop", matched as substrings. 943 of 3,079 items match at least one T1 keyword as a substring but only 306 as whole words. This inflates T1 (816). |
| Score formula 0.30/0.30/0.25/0.15 | ✅ | Matches `stage3_cluster.py`; recomputed all 10 scores exactly. |
| Score inputs | ⚠️ | **Recency = 0.65 for all ten themes.** That is the code's fallback for unparsable dates, so the 15% factor adds nothing and the date parse is almost certainly failing (corpus dates are naive ISO strings, `now` is timezone-aware). **Severity** is 0.66–0.74 for every theme (almost no discrimination). **Actionability** is hand-typed (0.80–0.95). **Frequency** is divided by the largest theme (T3 = 1.00). The ranking is therefore essentially frequency plus hand-set actionability. |
| README "multiplicative" score | ⚠️ | `multiplicative_score` is still emitted in `themes.json` (T3 0.4097) while the displayed rank uses the weighted sum. |
| SIP lifecycle windows 18.4 / 54.2 / 21.6 / 5.8 | ❌ | Literals in `app/page.tsx:35-38`; not computed anywhere. Tenure distribution of all 3,079 signals: unknown 3,011; beyond_12 35; pre_start 18; months_3_6 **6**; month_1 5; months_1_3 4. |
| Theme "what breaks" text | ⚠️ | Slide 2 T1: "Small early dips (−2% to −5%) lead to paused SIPs" is the hard-coded description. T1 actions in data: continued 48.9%, considering_stopping 48.8%, **cancelled 0.4%, paused 0.2%**. T3: continued 84.0%. |
| Golden set | ❌ | 20 items hard-coded in `evaluate_golden_set.py` with both `human_labels` and `engine_labels` as literals; the script never calls the extractor. 0/20 IDs or texts exist in the corpus; 4 items are "reddit". Human vs engine emotion + action identical in 19 of 20. **The 95.4% is not evidence about the engine.** |
| Evidence-Log corrections | ❌ | Corrections #1–#3 cite IDs `play_indmoney_01234`, `reddit_mf_00412`, `yt_comment_00892`, none in the corpus. Treat as illustrative at best; they must not be presented as real data points. |
| Representative quotes | ⚠️ | Live home page: T4 "Mandate & Payment Friction" is represented by a quote about brokerage charges; T7 by "best app to invest in US equities"; T3 by a request for consolidated transactions. |
| PII | ✅ | Regex scan of 3,079 filtered texts: 0 emails, 0 phone numbers, 0 PAN patterns. |
| `data/export/` | ❌ | Untracked; README says survey "N=35", `survey_mapping.json` provenance says "Constructed mock academic survey dataset (N=35)", and 10 "segments" with different names. The app's `ExportResearchButton` exposes it. Conflicts with N=26. Regenerate or remove. |

**What the engine can legitimately claim:** a corpus-level discovery of themes for human investigation (information clarity, red-number anxiety, payment friction, cross-sell annoyance) from 3,079 public signals, 36% of them about INDmoney. **What it cannot:** timing of drop-off, churn rates, prevalence, or tested extraction accuracy.

## F. Phase 4 — Segmentation audit

**Verdict: keep the structure, rename and re-define; do not call it a statistical segmentation.** Labels are rule-based archetypes (n is far too small to cluster).

| Segment | Definition (rule) | Behaviour | Core unmet need | Evidence (denominator) | Interviews | Confidence | Product implication |
|---|---|---|---|---|---|---|---|
| **A. Early-doubt first-timers** (was "Uncertain Newcomers") | First MF investment AND tenure ≤12 mo AND selected unsure/confusing | 8 of 9 confidence 1–3; 8 of 9 considered; 2 of 9 changed; 4 of 9 check daily+; 7 of 9 in months 3–6; 7 of 9 expected quick returns | "Is this normal for my stage?" | n=9 of 26 (14 first-year first-timers); INDmoney 4, Groww 5 | P01 (INDmoney), P05 (Groww, comparison) | Medium on need, **low** on churn link | Return explainer first |
| **B. Debit-disrupted** | Dedicated Q = "Yes, once/more than once" | 8 of 11 considered, 4 of 11 changed | Reason, SIP status, next step | n=11 of 26 (INDmoney 5) | P03, P00, P02 (adjacent) | Medium (descriptive 4/11 vs 1/14) | Failure explainer + pre-debit visibility |
| **C. Cash-flow-constrained** | Main reason = income drop / unexpected expense, or affordability-sized amount with a pause | 15 of 26 sized by affordability; 4 named a cash-flow reason, 1 changed (R23) | Reversible controls, restart prompt | n=4 (reason) / 15 (sizing) | P02, P00 | Low–medium | Pause-with-return-date; **don't drop** |
| **D. Goal-anchored continuers** | Active regular debits AND "No" to considering a change | 9 of 26 never considered; 12 of 26 continue as usual when red | Quiet, accurate goal view | n=9 | P04, P00 | Medium | Don't add nudges; use as the **holdout/guardrail population** |

Overlap: A and B overlap (3 of 9 in A also had a payment issue; 5 of 13 confused also had one). They are not mutually exclusive. State it.

**Disconfirming cases to show:** P04; 9 of 26 never considered a change; R08, a 3–6-month, confused, daily-checking Groww investor who didn't change; R15, a daily-checking INDmoney investor with confidence 2 who continued. **Comparative (not INDmoney prevalence):** Groww 8 of 26 (P05), bank 3, Zerodha Coin 1, adviser 1, other 2.

**Is the selected target the strongest opportunity?** Return confusion has the strongest *survey* support (13 of 26; 9 of 26 "most valuable change"). Payment friction has the stronger *actual-change* signal (4 of 11). Cash-flow has the only fully-documented *actual stopper* in interviews. No segment is proven as the churn driver. The honest statement is that return confusion is the most common stated problem and the best-evidenced *opportunity*, while the cause of stopping is mixed. Segment A is a defensible *pilot* target if the deck says so.
