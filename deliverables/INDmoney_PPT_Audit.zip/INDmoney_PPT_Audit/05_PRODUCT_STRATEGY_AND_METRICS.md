# 05 — Product Strategy, RICE, KPI Tree and Experiments

Evidence labels: **[F]** fact from data · **[I]** inference · **[R]** recommendation. All targets below are **proposed targets**; no baselines are known, so none are invented.

## A. Is the problem statement right?

> "Investors can see what happened to their SIP, but not what it means or what to do next."

**Verdict: keep. It is specific, testable and in the right shape (interpret, act, workaround).** Support by facet:

| Facet | Evidence (N=26 unless noted) | Strength |
|---|---|---|
| Return interpretation | 11 unsure whether returns are normal; 11 confusing terms; 16 confidence 1–3; 9 chose "clearer explanations" as the single most valuable change; P01, P05 [F] | **Strong** (self-reported, mixed platform) |
| Payment-failure communication | 11 payment issue (dedicated Q); 5 checklist; 4 rate clarity 1–2 of 11; 4 chose "recovery" and 3 chose "debit visibility"; P03, P00 [F] | Medium–strong |
| External seeking | 25 of 26 used a source; but "investment app" counts, and outside help also reassured P05 [F] | Weak as a *cause* |
| Expectation mismatch | 12 expected quick returns; 7 of 7 in the 3–6-month group (n=7) [F] | Medium, small n |
| Cash-flow and pause/restart | 15 sized by affordability; 4 gave a cash-flow reason, 1 changed; P02 [F] | Medium on mechanism; not covered by the proposed assistant |
| Trust/confidence | 16 of 26 low confidence; P03 "less sure the app would tell me things" [F] | Medium |

Gaps in the statement: it says nothing about **cash-flow shocks and restart**, the only fully-documented *actual stop* in interviews. Consider: *"…and when life changes, they can't pause, adjust or restart without losing the plan."* Otherwise say explicitly that cash-flow is a separate, later problem.

## B. Solution options and RICE

### Recomputed RICE (same formula as the deck: R×I×C÷E; R = share affected ÷ 10)
| Option | R at N=20 (deck) | R at N=26 | I | C | E | Score N=20 (deck) | Score N=26 |
|---|---|---|---|---|---|---|---|
| S1 Return Coach | 5.0 (10/20) | 5.0 (13/26) | 6 | 8 | 4 | 60.0 | 60.0 |
| S2 Debit Rescue | 4.5 (9/20) | 4.2 (11/26) | 5 | 6 | 5 | 27.0 | 25.4 |
| S3 Doubt Assistant | 7.5 (15/20) | 7.3 (19/26) | 7 | 7 | 6 | 61.25 | 59.7 |

Arithmetic in the deck is right. At N=26 S1 and S3 are tied (60.0 vs 59.7). **Critique**
- S3 is S1 ∪ S2, so its reach is a union (19 of 26) and larger by construction. A bundle always wins on R and loses on E, so RICE cannot separate them.
- I and E are team guesses; C uses N=20 evidence ranks. [I]
- Reach counts people who *report a problem*, not people the feature would *retain*. 5 of 6 who changed course are in the union and 1 (cash-flow) is not.

### Is the combined assistant better than a narrower first release?
**No, not as a first release.** [R] Reasons: (1) the eval burden doubles with two modes; the deck itself says "ship return mode first". (2) The Debit problem is mostly a **rules/copy problem** (reason, status, next step), which can be tested without an LLM, and the deck says the same. (3) The only quantity showing an *actual-change* gap is payment (4/11 vs 1/14), so Debit deserves its own, cheap, non-AI test rather than being folded into an LLM product.

### What to build, defer, remove, validate
| Action | Item | Why |
|---|---|---|
| **Build first** | Return mode: tenure-aware plain-language reading of the user's own figure ("−2% at month 5") with cited, descriptive "typical" ranges; refuses advice; "not sure + official link" fallback | Strongest evidence; cheapest; testable |
| **Build in parallel (non-AI)** | Failed-debit explainer from rules: reason code → plain text, SIP status, next step; day-before debit visibility as **user-set** reminder | Real friction (11/26); no LLM risk |
| **Build in parallel (non-AI)** | Restart prompt after pause ("pause until [date]", opt-in) | P02; 1 of 6 changers; cheap |
| **Defer** | AI "Debit mode" (free-text bank messages, Hinglish) | Until Return mode passes the gate |
| **Remove** | "fewer needless bank charges" as a value claim; "Hinglish" as an AI advantage; any "typical returns" that read as a prediction | Unsupported |
| **Validate before dev** | (a) 5–8 moderated sessions with first-year INDmoney investors using a Wizard-of-Oz Return reading on their *own* (or a scripted) red/flat figure. Measure comprehension, trust, "did it feel like advice?". (b) A legal/compliance read of "typical at this stage" wording. (c) Whether *any* explanation changes intent to continue: an intent survey, not retention. | Brief Part 6; avoids building on the "confusion → quitting" link that N=26 doesn't establish |

## C. North Star Metric audit

**Definition (from the brief):** % of first-time MF investors who still have an active SIP 12 months after starting their first. Active = ≥1 successful instalment in the last 30 days.

| Check | Finding |
|---|---|
| Measurable? | Yes, from INDmoney's own SIP and debit tables. |
| Denominator | Must be defined as a **cohort**: users whose *first-ever MF SIP* was registered in month M (exclude lump-sum-only). "First-time" needs a rule: no prior MF holdings on INDmoney, and no prior outside holdings detected through its CAS/tracker import (INDmoney tracks outside funds, so it can partly check). Without this, the denominator is a guess. |
| 30-day "active" | Sensible for monthly SIPs. INDmoney offers daily, weekly, monthly **and quarterly** SIPs (indmoney.com/mutual-funds, 2026-11-08), so a quarterly SIP is "inactive" in 2 of 3 months by this rule. Also: a SIP registered and not cancelled but whose latest debit failed is "inactive". And **fixed-tenure SIPs that completed before month 12** count as lapsed. [R] Define: *active = registered SIP with ≥1 successful instalment within its scheduled cycle +30 days*, and exclude completed-tenure SIPs from the denominator (report them separately). |
| Gaming risk | Raise active rate by nudging a ₹1 instalment, or restart just before month 12. Guardrail: amount and continuity of the *same* SIP. |

### Decomposition check
Deck: `12M Active = P₁ × P₂ × P₃ × P₄ + P₅`.
- ❌ **Mathematically invalid.** If P₁…P₄ are survival probabilities, their product is the probability someone *never lapses*. Recovery applies only to those who *did* lapse, so the term is `(1 − ΠPᵢ)·r`, not `+P₅`. The deck's version can exceed 100% and double-counts.
- ❌ **Inputs are not probabilities.** The values shown (18.4%, 6.3%, 54.2%, 21.6%) are shares of *drop-off signals* in a public-review corpus; 6.3% is a theme's corpus share and isn't a month-2–3 window at all. The four windows sum to 100% because they are shares of a *distribution*, not survival rates.
- ❌ P₂ ("autopay holds, months 2–3") overlaps P₁ (first instalment) and sits inside P₃'s period.

**Corrected form [R]**
`A₁₂ = S + (1 − S) · r`, where `S = s₁ · s₂ · s₃ · s₄` and `sₖ = P(still active at end of stage k | active at start of stage k)`.
Stages: (1) first instalment lands (days 0–35); (2) mandate/autopay holds through instalments 2–3; (3) survives months 3–6; (4) survives months 6–12; `r` = share of users who lapsed in stages 2–4 and are active again at month 12.
All five terms are **to be instrumented**. Show no numbers until they are measured.

### KPI tree
```
NORTH STAR  12-month active SIP rate, first-time-investor cohort   (proposed definition above)
│
├─ INPUT 1  First instalment lands (s₁)         ← setup completion; first-debit success rate
├─ INPUT 2  Autopay holds (s₂)                  ← debit success rate by instalment #; failed-debit recovery within 7d
├─ INPUT 3  Survives months 3–6 (s₃)            ← pause/cancel rate in months 3–6; share who see red/flat and stay
├─ INPUT 4  Survives months 6–12 (s₄)           ← same, months 6–12
└─ INPUT 5  Recovery (r)                        ← paused/lapsed SIPs reactivated within 60d
│
LEADING INDICATORS (weeks)
  • Share of red/flat-figure sessions that open "Is this normal?"            • Comprehension check (≥2 of 3 correct)
  • Failed-debit → resolved ≤7 days                                           • Opt-in rate for pre-debit reminder
  • Pause-intent exits that choose "reduce" or "pause until date" instead of cancel
GUARDRAILS
  • Advice-refusal compliance 100% (human-audited sample)   • "Felt like advice" rate in feedback (target: ~0)
  • Additional cancellations / complaints after exposure     • Notification opt-out rate and unsubscribe
  • Support-contact rate per exposed user (should not rise)   • SIP amount reduction rate (should not rise unexpectedly)
AI QUALITY (offline + online)
  • Correct on rule questions (target ≥95%, proposed)         • Invented fee/limit rate (target 0)
  • Fallback rate ("not sure") and fallback accuracy          • Citation-present rate (100%)
  • Human-rated clarity and tone (sampled weekly)             • Latency p95
OPERATIONAL
  • Cost per answered query                                   • Model/rules-table version drift incidents
  • Rules-table freshness (days since last verified vs RBI/AMC/bank change)
```

## D. Experiments (all "proposed", baselines to be measured first)

Common design: randomise at user level; cohort = first-time SIP investors on INDmoney in months 2–11; keep a ≥10% never-exposed holdout; exclude users in a legal-hold or complaint state; pre-register primary metric; because the NSM needs 12 months, read **90-day continuation** as the primary proxy and the 12-month NSM as a lagging confirmation. Sample size: compute from the *measured* baseline and chosen MDE; the group sizes in this survey (n=9–14) cannot guide it.

| # | Hypothesis | Cohort | Control / treatment | Primary | Secondary | Guardrails | Min. period | Success criteria (proposed) |
|---|---|---|---|---|---|---|---|---|
| E0 | A scripted plain-language reading raises comprehension and intent to continue | 5–8 first-year INDmoney investors (moderated, Wizard-of-Oz) | Own red/flat figure shown: current screen vs screen + reading | Comprehension (3 questions) | Trust, "felt like advice?", intent to continue | Distress/anxiety reports | 2 weeks | ≥6 of 8 answer ≥2 of 3 correctly; 0 describe it as advice |
| E1 | Return mode reduces pause/cancel after a red or flat figure | Months 2–6, XIRR ≤ 0 at session | Current screen vs Return mode (card + explainer) | Pause/cancel within 30 days of first exposure | Opens, 90-day active, support contacts | Advice-refusal compliance; complaint rate; opt-outs | 12 weeks exposure, 90-day read | Statistically significant reduction at a pre-set MDE; no guardrail breach |
| E2 | Rules-based failed-debit explainer raises recovery | Users with ≥1 failed debit | Generic "instalment failed" vs reason + status + next step + retry | Recovery within 7 days | Repeat failure, 90-day active | Duplicate-debit incidents; bank-charge complaints | 8 weeks | Higher 7-day recovery at pre-set MDE; zero duplicate debits |
| E3 | Opt-in day-before reminder cuts missed instalments | Users with ≥1 failed debit or low-balance flag | No reminder vs opt-in reminder | Failed-debit rate next 2 cycles | Opt-in rate | Notification opt-out; fatigue complaints | 2 cycles | Lower failure rate without higher opt-out |
| E4 | Pause-until-date + restart prompt reduces permanent lapse | Users who pause | Plain pause vs pause-with-date + opt-in restart | Reactivated ≤60 days | 12-month active | Complaints about prompts | 90 days | Higher reactivation at pre-set MDE |
| E5 | AI Debit mode adds value over rules (only if E2 passes) | Failed-debit users | Rules explainer vs AI explainer | 7-day recovery | Free-text query resolution | As E1 plus invented-fee rate = 0 | 8 weeks | AI ≥ rules on primary with 0 invented facts |

## E. Safety constraints (carry onto the prototype and safety slides)
- No fund or stock recommendation; no "continue/stop/buy"; no fear, FOMO or urgency (including countdowns and loss framing).
- "Typical at this stage" statements are descriptive, cited and never predictions. Show source and date.
- Visible "not investment advice" label; safe fallback: *"Not sure — here is the official source."*
- Reminders are user-set, never system-pushed urgency.
- Log queries and answers for audit with PII masked.
