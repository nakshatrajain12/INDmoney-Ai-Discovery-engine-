# 02 — Slide-by-Slide Review

Deck: 10 slides, 20 × 11.25 in (16:9), Arial body at 17–19 pt, Canva Sans for nav. Claim IDs (e.g. F-S3-04) refer to rows in `03_FACT_CHECK_REGISTER.csv`. Priorities: **P0** must fix before submission · **P1** high impact · **P2** useful · **P3** polish.

## Part 1 — Inventory

| # | Title | Purpose | Visual | Chars | Standalone? | Duplicates | Missing | Advances story? |
|---|---|---|---|---|---|---|---|---|
| 1 | INDmoney Mastered Wealth Onboarding — But is Failing Retention | Context, market, goal, NSM breakdown | 5 stat tiles, 1 column chart, 3 competitor blocks, formula block | 2,109 | Mostly | NSM breakdown re-appears on slide 6 | INDmoney-specific retention; user-journey | Yes, but the title overclaims |
| 2 | 8,179 Posts Became 3,079 Signals: SIPs Break in Months 3–6 | AI discovery engine | 5-step pipeline, source bar chart, theme table, window column chart | 1,110 | Yes | Windows repeat slide 1 tile 5 | Platform mix, method limits, eval evidence | Yes, but the headline is unsupported |
| 3 | Only Confused First-Timers Changed Course: 4 of 10 vs 0 of 5 Clear | Segmentation + hypotheses | Text cards only | 2,929 | No (dense) | Hypotheses repeat slide 5 | A chart; N=26; INDmoney-only | Yes; title falsified at N=26 |
| 4 | Confusion, Not Panic: 8 of 20 Can't Tell If Returns Are Normal | Survey and interview synthesis | 4 tiles, 3 bar charts, 2 personas, 5 quote notes | 2,243 | Yes | Overlaps slide 5 numbers | P00; N=26; provenance disclosure | Yes |
| 5 | Clarity and Payment Gaps Hold Up; Panic and Cross-Sell Are Unproven | Engine vs research validation | Verdict table, 4 tier chips, hypothesis cards | 1,671 | Yes | Repeats slide 3 hypotheses | All 16 not visible; N=26 | Yes |
| 6 | Newcomers Can See Their SIP but Not What It Means or What to Do | Problem definition | 5-box chain + 5 text panels | 2,608 | Mostly | Chain repeats slides 1/2/4/5 | Sizing, journey map | **Yes — best slide** |
| 7 | Explain Returns First, Debits Second: One Assistant, Two Modes | Solution options + RICE + AI safety | 3 option cards, RICE table, 2 text panels | 2,455 | Dense | — | Prototype link, scope decision, what's cut | Yes |
| 8 | (none) | **Prototype** | **Empty** | 0 | n/a | — | Everything | **No** |
| 9 | (none) | **Metrics & usability testing** | **Empty** | 0 | n/a | — | Everything | **No** |
| 10 | (none) | **GTM & risks** | **Empty** | 0 | n/a | — | Everything | **No** |
| — | (none) | **Sources** | **Not in deck** | — | — | — | Citations only exist in speaker notes | — |

**Narrative-flow verdict.** The sequence Overview → AI Engine → Segmentation → User Research → Validation → Problem → Solution → Prototype → Metrics & Usability → GTM & Risks → Sources mirrors the reference deck and is coherent. Two structural issues:

1. **Segmentation (slide 3) precedes the research that creates it (slide 4).** The reference deck has the same order, so it is acceptable, but slide 3 then leans on survey numbers the audience hasn't seen. Add a one-line sample-and-method strip to slide 3, or reorder to Research → Segmentation → Validation. I recommend keeping the order and adding the strip.
2. Slides 4 and 5 are two views of the same evidence. Merge their shared numbers into one evidence set and keep slide 5 as the *engine-vs-research* verdict only.

Add: Prototype walkthrough, AI quality and safety slide, KPI tree and experiments, usability test, GTM and risks, Sources, plus an appendix with the sensitivity table and evidence-integrity note. Details in file 06.

---

## Part 2 — Per-slide review

### Slide 1 — Overview

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 1 | Title "…Mastered Wealth Onboarding — But is Failing Retention" | Punchy | "Mastered onboarding" and "failing retention" are assertions with no INDmoney data. Note 57 says INDmoney publishes no SIP retention. | UNSUPPORTED (F-S1-01) | Retitle: *"Starting a SIP is easy to copy. Keeping it going is INDmoney's opening."* | **P0** |
| 1 | Tile "78.5% SIP stoppage ratio" | Caveat is in the notes | Reads as "78.5% quit". The number is *stopped-or-ended ÷ new registrations* in one month and includes completed tenures. | VERIFIED WITH QUALIFICATION (F-S1-05) | Relabel on the slide: "49.7 lakh SIPs stopped or ended per 63.3 lakh started, Sep 2026". Put "includes completed SIPs" on the tile, not just in the notes. | P1 |
| 1 | Tile "54.2% of drop-off signals in months 3–6" | — | Hard-coded constant; 6 of 3,079 signals are tagged 3–6 months | UNSUPPORTED (F-S1-09) | Remove. Replace with "36% of 3,079 clean signals are about INDmoney" or the real 3–6-month survey cohort: "7 of 7 in the 3–6-month survey cohort expected quick returns (n=7)". | **P0** |
| 1 | Chart "SIP assets held 5+ years: regular 34.4% vs direct 19.9%" + "29% under 1 year" | Sources named | Mixes Outlook (34.4/19.9) with Cafemutual (its table: 34.09/19.64; "under 1 year" 28.95%). Direct plans are growing fast, so younger assets are partly a growth effect and a ticket-size effect (Outlook: regular SIPs skew larger), not proof of weaker retention. Says nothing about INDmoney. | VERIFIED WITH QUALIFICATION (F-S1-06/07) | Use one source. Add a footnote: "asset-weighted, industry, direct-plan base is growing; not INDmoney retention". | P1 |
| 1 | 10M+ investors vs competitor block "INDmoney 7.19 L active clients" | Caption says NSE broking clients | The two INDmoney numbers sit on one slide with no reconciliation | VERIFIED WITH QUALIFICATION (F-S1-02/10) | Add "(app investors, company-reported)" vs "(NSE active broking clients)". Better, drop the 7.19 L bar and keep Groww/Zerodha as context. | P2 |
| 1 | Metric breakdown `12M Active = P₁×P₂×P₃×P₄ + P₅` with 18.4% / 6.3% / 54.2% / 21.6% | Showing a decomposition at all is right | The formula is invalid (adding a recovery probability to a product); the percentages are shares of *drop-off signals*, not conditional survival rates; "6.3%" is a theme share, not a month-2–3 window. | INCORRECT (F-S1-12…15) | Replace with the corrected tree (file 05 §C): `A₁₂ = Πsₖ + (1−Πsₖ)·r`, with each stage labelled "to be instrumented", no engine percentages. | **P0** |
| 1 | Launch & features: "UPI Autopay… SIP Center: edit, pause or cancel anytime" | Sourced | indmoney.com/mutual-funds says SIPs run "through INDpay UPI" and are managed in the "SIP Centre"; the "edit, pause or cancel anytime" wording was not on the page. It also offers daily, weekly, monthly and quarterly SIPs, which matters for the 30-day "active" definition. | VERIFIED WITH QUALIFICATION (F-S1-04) | Quote the page's words. Note SIP frequency in the NSM definition. | P2 |

Notes on slide 1: **scrub the notes.** They contain "CAVEAT" lines (good) but also working notes. Keep citations, move the working notes out.

### Slide 2 — AI Engine

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 2 | Title "…SIPs Break in Months 3–6" | Specific | The window shares are hard-coded; 97.8% of signals have unknown tenure | UNSUPPORTED (F-S2-10) | Retitle: *"8,179 posts → 3,079 signals: public reviews say 'I don't understand my returns' and 'my debit failed'."* | **P0** |
| 2 | 5-stage pipeline | Clear and brief | Stage 4 "Signals form 10 themes" overstates: themes are pre-defined and signals assigned by keyword/emotion affinity. Stage 5 "20-item golden set tests the engine" is not what the script does. | INCORRECT / misleading (F-S2-06, F-S2-12) | Stage 4: "Signals are assigned to 10 pre-defined themes and scored". Stage 5: "Quality check: re-labelling a blind 40–50 item sample (in progress)". Only report results you have run. | **P0** |
| 2 | Source chart (74/11.3/7.6/3.8/3.3%) | Correct; n shown | Doesn't show *which product* the reviews concern: INDmoney 36.2% of clean signals; Zerodha Coin 25.6%; Groww 15.4%. "Play Store (6,054)" includes Groww and Zerodha Coin apps. | VERIFIED WITH QUALIFICATION (F-S2-03/04) | Switch to a stacked bar by platform, or add a caption "36% INDmoney". | P1 |
| 2 | Top-5 theme table | Scores and counts match the code | Missing label: "corpus share, not prevalence" (it's in the notes only). "What breaks" text for T1 ("lead to paused SIPs") is the hard-coded description; data show 0.6% paused or cancelled. | VERIFIED / UNSUPPORTED (F-S2-07/08) | Add a column "% signals with a recorded stop" (T1 0.6%) or reword to "show anxiety; 49% 'considering stopping' in text". Rank by score is fine, but note recency is constant (all 0.65). | P1 |
| 2 | Window chart "Share of drop-off signals by SIP age" | — | Not derived from data | UNSUPPORTED | **Delete the chart.** Replace with a "How much do we know about timing?" bar: 3,011 unknown vs 68 known, which is itself an honest insight. | **P0** |
| 2 | Opportunity-score formula | Matches the code | The factor design is weaker than the slide implies (frequency normalised to the top theme; severity near-constant; actionability hand-typed; recency broken) | VERIFIED WITH QUALIFICATION (F-S2-09) | Footnote "discovery heuristic; hand-set actionability". Fix recency in code before the demo. | P1 |

### Slide 3 — Segmentation

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 3 | Title "Only Confused First-Timers Changed Course: 4 of 10 vs 0 of 5 Clear" | Very quotable | OUTDATED, and at N=26 it is not supported (4/12 vs 1/8 overall; 2/9 vs 1/5 in first year). | OUTDATED (F-S3-01) | Retitle: *"13 of 26 are unsure or confused about returns — and 5 of the 6 who changed course were among them."* Show the 2/9 vs 1/5 first-year count in a footnote. | **P0** |
| 3 | Segment 1 "Uncertain Newcomers", "7 of 15 first-timers" | Clear rule-based definition; labelled not statistical | Recompute: **9 of 14 first-year first-timers** (20 first-timers in all); INDmoney 4, Groww 5; 2 changed (1 INDmoney, 1 Groww); 8 of 9 confidence 1–3; 4 of 9 daily+; 3 of 9 payment issue | OUTDATED (F-S3-02…08) | Replace all numbers; add an INDmoney-only column (n=4). Rename "Early-doubt first-timers". | **P0** |
| 3 | Segment 2 "Cash-Flow Jugglers": "no survey respondent here changed course… 3 of 20… all kept going" | Honest "why not selected" | **Wrong at N=26**: 1 of 4 with a cash-flow reason changed (R23 paused). P02 is the interviewed actual stopper. "Rank 11 of 16" is N=20-based and the register now says "supported" | INCORRECT (F-S3-10/11) | Update to 15 of 26 sized by affordability; 4 named a cash-flow reason, 1 changed. Change "Not selected" to "Next wave — reversible controls tested as non-AI". | **P0** |
| 3 | Segment 3 "Anchored Planners": "8 of 20… 9 of 20" | P04 as disconfirmer is a strength | Now 9 of 26 never considered a change; 10 of 26 confidence 4–5 | OUTDATED (F-S3-12) | Update numbers. Reuse as the guardrail population. | P1 |
| 3 | "Why selected": ranks T3 #1, T4 #2, H1 #3 | Triangulates three sources | Numeric ranks are N=20-based. Caveat "P01 stayed partly because loss was small" is excellent. | OUTDATED / INFERENCE (F-S3-14) | Show tiers or re-rank. Keep the caveat. | P1 |
| 3 | Hypotheses H1–H3 cards | Good "We believe… If… then" form | Overlap with slide 5; no test metric | RECOMMENDATION | Move to the experiment slide with a metric per hypothesis; keep one line here. | P2 |
| 3 | "Sizing (illustrative): 7 of 9 first-year first-timers are active; both off-track are Uncertain Newcomers" | Labelled illustrative | At N=26: **11 of 14** first-year first-timers have an active SIP; the 3 who aren't (R18, R19, R23) include one non-confused. "Both off-track are Uncertain Newcomers" is false at N=26. | OUTDATED / INCORRECT (F-S3-15) | Replace or delete. | P1 |
| 3 | Layout | — | 2,929 characters, text-only | — | One chart: a 14-person "first-year first-timers" waffle grid coloured by confused / changed. Cards shrink to 2 lines each. | P1 |

### Slide 4 — User Research

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 4 | Title "Confusion, Not Panic: 8 of 20 Can't Tell…" | Strong framing | N=20. At N=26: **11 of 26** unsure, 11 of 26 confusing terms, 13 either. | OUTDATED (F-S4-01) | "Confusion, Not Panic: 11 of 26 can't tell if returns are normal". | **P0** |
| 4 | Tiles: 8/20, 9/20, 5/5, 4/20 | Tiles are well chosen | Replace with 11/26; 11/26 payment issue (4 of 11 rate clarity 1–2); 7/7 in the 3–6 month group; 17 of 26 considered, 6 changed | OUTDATED (F-S4-02…05) | Re-state with denominators. Add "n=26 incl. 5 interview-mirror rows" in the evidence line. | **P0** |
| 4 | Chart 1 "First move when returns flat or red" | Good | N=26 counts: continue 12, YouTube 4, family/friends 2, Google/articles 2, in-app 2, adviser 1, Reddit 1, never experienced 1, pause/stop 1 | OUTDATED (F-S4-06) | Replace; "Other" bucket can be dropped. | P1 |
| 4 | Chart 2 payment issue | — | N=26: No 14, once 6, more than once 5, not sure 1 | OUTDATED (F-S4-07) | Replace; show "not sure" as its own bar. | P1 |
| 4 | Chart 3 help sources | Multi-select noted | N=26: friends/family 11, Google 10, investment app 8, YouTube 7, Reddit 7, adviser 6, influencers 4, AMC 3, don't seek 2. "In-app help" at 6 on the slide vs "Investment app" 8 in data. | OUTDATED (F-S4-08) | Replace. Note that 25 of 26 selected at least one source *including* "investment app", which isn't "outside the app". Reword as "look outside or inside". | P1 |
| 4 | Personas P01, P03 | Clear JTBD "our synthesis" label | Both are INDmoney; P03 is not in Segment 1. Persona 2 mismatches the selected segment. | INFERENCE | Make persona 2 explicitly "adjacent: debit". Add P02 (cash-flow) or P04 (continuer) as a counter-persona. | P1 |
| 4 | Interview notes: 5 quotes | Verbatim matches the records | P00 is absent. Records are "condensed". | VERIFIED (F-S4-10) | Add "P00, researcher-user (positional): one failed debit, ₹300 penalty (unverified)". Say "condensed notes". | P1 |
| 4 | "What cuts against the story" | Excellent | — | — | Keep; add R08/R15 (confused, didn't change) and the 9 of 26 never considered. | P2 |
| 4 | Notes: "Updated N=26 is provisional and not used here" | — | Contradicts your instruction; also leaks internal provenance flags | — | Rewrite notes; move the integrity text to the appendix slide. | P1 |

### Slide 5 — Validation

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 5 | Engine-vs-research table (T3, T1, T4, T8) | Strong format; mirrors the reference deck | All research cells are N=20; ranks are N=20-based | OUTDATED (F-S5-01…05) | T3: 11/26 unsure, 11/26 terms, 9/26 want clearer explanations. T1: 12/26 continue as usual, 1/26 pause/stop first. T4: 11/26 payment issue; changed 4/11 vs 1/14. T8: no survey measure. | **P0** |
| 5 | Hypothesis cards H1–H3 | Verdicts match the register | H1: 7/7, 6/7, 2/7 (n=7). H2: update per above. H3: 25/26 external; 2/26 external advice main reason. | OUTDATED (F-S5-06…08) | Update; add "includes 2 interview-mirror rows" to H1. | **P0** |
| 5 | 16-hypothesis tiers | Shows all 16 | Tier 3 lists "Flexible controls" as partial; the N=26 register says "reframed and supported" | OUTDATED (F-S5-09) | Move P-H1 to Tier 2. Show tiers only, no #1–#16. | P1 |
| 5 | "What we didn't see coming" | Great idea (copied from the reference) | Bullet 2 ("none of the 5 who weren't") is falsified; replace with "Payment issue separated *actual* change (4/11 vs 1/14), not consideration (8/11 vs 8/14)" and "Cash-flow, not returns, drove the one interviewed stopper". | OUTDATED (F-S5-10) | Rewrite | **P0** |
| 5 | Key insight | Clear | OK with correction: "both fixable without advice" is a recommendation, not a finding | RECOMMENDATION | Tag as "Our read" | P2 |

### Slide 6 — Problem

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 6 | Evidence chain (5 boxes) | **Best element in the deck**; meets brief Part 4 | Box 4 numbers are N=20; box 3 says "cannot show who quit", which is correct and good | OUTDATED (F-S6-01) | Update box 4: "13 of 26 confused; 11 of 26 payment issue; panic not shown". | P0 |
| 6 | "True problem" statement | Specific and testable: interpret / act / workaround | "Interpreting" half is well supported; "Acting" half rests on 11/26 plus P03 and P00; "Workaround… advice conflicts" rests on 2 interviews | INFERENCE | Keep the sentence. Add confidence tags (High / Medium / Medium). | P1 |
| 6 | "Who" panel: "7 of 15 first-timers" | — | → 9 of 14 first-year first-timers; INDmoney 4. | OUTDATED | Update | P0 |
| 6 | "Value": "fewer needless bank charges" | — | No evidence of charges in the survey; only P00's unverified ₹300 | UNSUPPORTED (F-S6-05) | Remove or label as P00-reported | P1 |
| 6 | "Why now": ₹32,490 Cr; "20 of 20 already look outside the app" | Sourced | "20 of 20" → 25 of 26, and the item includes "Investment app"; the inflow figure is verified but is industry-wide, which doesn't show urgency *for INDmoney*. | VERIFIED WITH QUALIFICATION | Reword | P2 |
| 6 | Notes | Explicit about sizing | Contain "root cause is a hypothesis" (good) | — | Keep that sentence on the slide | P2 |

### Slide 7 — Solution

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 7 | Three options S1/S2/S3 | Real alternatives with weaknesses | "Reaches 15 of 20" → 19 of 26 (a union, so larger by construction). "Link to quitting unproven (6 of 9 vs 6 of 11)" → 8/11 vs 8/14 considered; 4/11 vs 1/14 changed. | OUTDATED (F-S7-01…03) | Update; state that S3 ⊃ S1 ∪ S2. | **P0** |
| 7 | RICE table: 60 / 27 / 61 | Arithmetic correct (60.0, 27.0, 61.25); transparent inputs; "tie" stated; sensitivity given | At N=26: R = 5.0, 4.2, 7.3 → about 60 / 25 / 60. I, C and E are team judgement. "C from evidence rank" uses N=20 ranks. | VERIFIED (arith) / OUTDATED (inputs) (F-S7-04…06) | Recompute; keep the "tie" language; add one-line decision: *ship Return mode first; Debit mode as a rules-based explainer; AI only if Return mode passes its gate.* | P0 |
| 7 | "Not built: reversible controls (non-AI, rank 11 of 16)" | Honest about scope | Weakest decision on the slide. 1 of 6 changers and the only interviewed stopper were cash-flow. No restart prompt is a cheap non-AI fix. | RECOMMENDATION | Move to "Build in parallel, non-AI: restart reminder after pause" rather than "not built". | P1 |
| 7 | "Where AI earns its place" | The strongest argument: messy input, Hinglish | "Hinglish" wasn't tested anywhere. "Rules own the facts" is right. | INFERENCE | Mark Hinglish as a hypothesis; show the rules table as a visual | P2 |
| 7 | Eval gate targets (≥95%, 100% refusal, 0 invented fees) | Targets, not results, clearly labelled | "40-scenario golden set" needs to exist. The existing 20-item set is not usable (see file 04 §E). | RECOMMENDATION | Add "40 scenarios built: yes/no, date" | **P0** |
| 7 | Slide density | — | 2,455 chars at 18–19 pt | — | Move the RICE notes and eval gate to slide 9; keep options + decision | P1 |

### Slides 8–10 and Sources

| Slide | Current content | What works | What is wrong or missing | Evidence issue | Recommended change | Priority |
|---|---|---|---|---|---|---|
| 8 Prototype | Nav only | — | No walkthrough of the MVP (brief Part 5: deployed, eval-gated, visible quality check, safe fallback, "not advice" disclaimer) | — | 6-step flow with real screenshots, deployed URL, the fallback ("not sure" plus official source) and the disclaimer shown on-screen | **P0** |
| 9 Metrics & usability | Nav only | — | No NSM definition, KPI tree, experiments or usability results (brief Part 6: ≥3 target users) | — | NSM + tree (file 05); usability results table **only from real sessions**; otherwise "test plan: 3+ users, task, success criteria; results pending" | **P0** |
| 10 GTM & risks | Nav only | — | Nothing on rollout, risks, mitigations | — | Phased rollout, risks (wrong explanation, perceived advice, over-notifying, regulatory), each with a mitigation and a metric | **P0** |
| 11 Sources | Not present (nav lists it) | — | Citations live only in speaker notes, which are not visible in presentation mode or PDF export | — | One slide listing every source with access date; add appendix | **P0** |
