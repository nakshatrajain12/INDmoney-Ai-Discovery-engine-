# 01 — Executive Audit: "INDmoney: Mastered Wealth Onboarding — But Is Failing Retention"

Audit date: 2026-11-08 · Deck audited: `NL_INDmoney Solution.pptx` (SHA-256 `61b05dd3…f55a`, byte-identical to `NL_INDmoney_Solution_Latest.pptx` in the research pack) · Not modified.

## A. Executive verdict

**The deck is not submission-ready.** The thinking in slides 3–7 is honest and unusually well caveated. It still fails on four counts, and each could cost you the submission.

| # | Blocker | Evidence |
|---|---|---|
| 1 | **Three of the ten slides are empty.** Slides 8, 9 and 10 (Prototype, Metrics & Usability Test, GTM & Risks) contain only the navigation tabs. There is no Sources slide, although the nav on slide 1 lists one. | `deck.txt` dump: slides 8–10 have 22 shapes each and 122 characters of text (the nav labels only). The brief's Part 5 (deployed eval-gated MVP) and Part 6 (test with ≥3 users) have no slide. |
| 2 | **Slides 3–7 still use N=20.** Every survey number on those slides is superseded by the N=26 you told me to use. Slide 4's notes say "Updated N=26 is provisional and not used here". | At N=26 the slide-3 headline "4 of 10 vs 0 of 5" becomes 4 of 12 vs 1 of 8 (first-timers of any tenure). Among first-timers in their first 12 months it becomes **2 of 9 vs 1 of 5**, which is no separation at all (see file 04 §B). |
| 3 | **The headline engine claim is hard-coded, not measured.** "54.2% of drop-off signals fall in months 3–6" and the whole "SIPs break in months 3–6" slide title come from constants typed into `app/page.tsx:35-38`. | In the data, 3,011 of 3,079 clean signals (97.8%) have `sip_tenure = unknown`. Only **6** are tagged `months_3_6`, and only 50 carry any in-SIP tenure window. The deck's own slide-6 note admits the engine "has tenure for 2.2%". |
| 4 | **The golden-set accuracy (95.4%) is not a measurement of the pipeline.** The "engine" labels are literals in `pipeline/evaluate_golden_set.py`. | 0 of the 20 golden items exist in the 8,179-row corpus (by ID or text). Four are tagged `reddit`, yet the corpus has zero Reddit rows. |

Related problems:
- **The title asserts something you have no INDmoney data for.** "Failing Retention" has no INDmoney retention figure behind it. Your own slide-1 note says "INDmoney does not publish SIP retention".
- **The NSM decomposition `P1×P2×P3×P4 + P5` is mathematically invalid**, and its inputs are shares of drop-off signals, not conditional survival probabilities.
- **The selected target segment is mostly not INDmoney.** At N=26 "Uncertain Newcomers" is n=9, of whom 5 are Groww and 4 are INDmoney.
- **Only 1 of your 6 interviews (P01, plus Groww P05) sits in the chosen segment.** The brief asks for 5–6 interviews *with the chosen segment*.
- **Five of the 26 survey rows (R22–R26) are near-verbatim copies of P01–P05.** The N=26 you asked me to use therefore double-counts the interview participants. Nothing in the deck or the final report discloses this.

### What is genuinely good (keep it)
- The evidence-chain on slide 6 (Business metric → Outcomes → AI discovery → Research → Problem) is exactly what Part 4 of the brief asks for.
- The "What cuts against the story" box and the P04 disconfirming case.
- RICE shown with its inputs and honest limits (S1 vs S3 is a tie).
- The explicit refusal to call engine scores "validation".
- Slide 7's recognition that the existing golden set cannot test generated answers, and the proposal of a new 40-scenario set with pre-set targets.
- External statistics. 11 of 13 I checked are correct against the cited pages (file 03); the other two need caveats.

### Readiness scorecard
| Dimension | Status | Comment |
|---|---|---|
| Completeness vs brief | 🔴 | Parts 5–6 (MVP, user testing) and sources absent. |
| Factual accuracy | 🔴 | N=20 on 5 slides; hard-coded engine windows; mislabelled decomposition. |
| Research integrity | 🟠 | Good caveats, but N=26 provenance (R22–R26) undisclosed and the 3-row platform correction undocumented. |
| Narrative | 🟠 | Strong spine; headline stat collapses at N=26 and must be rewritten. |
| Strategy | 🟠 | Problem statement sound; solution bundling and KPI maths need rework. |
| Design | 🟠 | Consistent and clean, but text-heavy (1,700–2,900 characters on slides 3–7), no screenshots or visuals. I could not render the slides (no PowerPoint/LibreOffice here), so design findings come from shape and font metrics plus the reference PDF text. |

## B. Top 15 highest-impact changes (ranked)

1. **Build slides 8–10 and a Sources slide** (prototype walkthrough, eval gate and usability results, KPI tree and experiments, GTM and risks). Without them the deck covers 4 of the brief's 6 parts. Take prototype and usability content from what you actually built and ran. If the usability test has not happened, say so and show the plan. **Do not fabricate results.**
2. **Re-run every survey figure at N=26** and state the denominator on every number (file 03 has the replacement values row by row).
3. **Rewrite the slide-3 title and logic.** Retire "Only confused first-timers changed course" and use the N=26 version: *Confusion is the most common stated problem (13 of 26 unsure or confused; 16 of 26 rate confidence 1–3) and 5 of the 6 who changed course reported it. The counts are too small to call it the separator.*
4. **Remove or re-source "54.2% / 18.4% / 21.6% / 5.8%"** (slides 1 and 2, the notes, and the live site). Either compute the windows from tagged signals, which gives n=50 and no 3–6-month claim, or drop them and lean on the 3–6-month survey cohort (n=7, framed as hypothesis-generating).
5. **Replace the golden-set claim.** Run `stage2_extract` on the 20 items, or hand-label 40–50 randomly drawn real corpus rows blind to the engine, and report *those* numbers. Until then, delete "95.4%" from every artefact.
6. **Fix the title.** Replace "Mastered Onboarding — But Failing Retention" with something you can support: *"Starting a SIP is copyable. Keeping it going is where INDmoney can differ."* The slide-1 "Our take" already says this.
7. **Disclose N=26 composition.** Add a footnote: *26 = 21 independent responses + 5 entries (R22–R26) that mirror interview cases P01–P05; results shown for N=26 and N=21 (file 04 §A).*
8. **Fix the metric decomposition.** Use `A₁₂ = (Π sₖ) + (1 − Π sₖ)·r`, with conditional survival stages and a recovery term, and label every input "to be instrumented" (file 05 §C).
9. **Re-define the target segment honestly.** Say "first-year first-time investors who report confusion about returns (n=9 of 26; INDmoney 4, Groww 5)" and treat the 3–6-month cohort (n=7) as the sharpest sub-signal. Add a second INDmoney-only column.
10. **Close the interview-fit gap.** State that P02, P03 and P04 are adjacent or disconfirming cases and that only P01 (INDmoney) and P05 (Groww) are in the target. Schedule 3–4 more interviews with INDmoney first-year investors who saw a red or flat return, or reposition the segment to match the interviews you have.
11. **Re-do the RICE** at N=26 (R = 5.0 / 4.2 / 7.3 gives about 60 / 25 / 60) and make the real decision explicit. S3's reach is a union of S1 and S2, so it wins on reach by construction. The defensible plan is to ship Return mode first, behind the eval gate, and test Debit mode in parallel as a *non-AI* rules explainer.
12. **Stop calling the payment link unproven in the old way.** At N=26 the descriptive gap in *actual* change is 4 of 11 vs 1 of 14 (Fisher p≈0.13; considered 8 of 11 vs 8 of 14). Report both and keep "not causal".
13. **Recompute the engine facts you show.** Add that only 36.2% of clean signals (1,114 of 3,079) are INDmoney, the rest being Zerodha Coin, Groww and general threads, and that themes are pre-defined, with signals assigned by keyword affinity. Fix the recency factor, which is a constant 0.65 for every theme.
14. **Scrub speaker notes and the export folder.** Notes contain "CHECK BEFORE SUBMITTING" lists and provenance flags. `data/export/survey_mapping.json` still says "Constructed mock academic survey dataset (N=35)", and a download button ships it. Fix or withdraw it before anyone downloads it.
15. **Reduce density on slides 3, 6 and 7** (2,455–2,929 characters each). Move caveats into a footnote band and use one visual per slide: a segment-funnel chart, an evidence-chain diagram, and an option-comparison matrix.

## C. How to read the rest of the audit
| File | Content |
|---|---|
| `02_SLIDE_BY_SLIDE_REVIEW.md` | Inventory plus per-slide review tables, P0–P3 |
| `03_FACT_CHECK_REGISTER.csv` | Every claim, source, status, correction |
| `04_RESEARCH_AND_SEGMENTATION_AUDIT.md` | N=26 recomputation, interviews, hypotheses, engine verification, segmentation |
| `05_PRODUCT_STRATEGY_AND_METRICS.md` | Problem, solutions, RICE, KPI tree, experiments |
| `06_DESIGN_AND_STORYTELLING_RECOMMENDATIONS.md` | Design audit and proposed final sequence |
| `07_FINAL_ACTION_PLAN.md` | Correction list, research gaps, checklist |

## D. Limits of this audit
- I could not render slides (no PowerPoint or LibreOffice on the machine), so I judged layout from shape geometry, font sizes and extracted text. Slide screenshots were not reviewed.
- The AI Copilot (`/ask`) was not exercised. I verified the live home page against the repository and the data files.
- I did not independently verify TechCrunch (Series D), the Zerodha-Coin description (Jainam blog) or the IANS/Telangana Today copy of the SIP-inflow story. The Angel One copy confirms the same figures.
- Whether P01–P05 are real, recruited interviews cannot be established from the files. I flag the risk in file 04 and leave the decision to you.
